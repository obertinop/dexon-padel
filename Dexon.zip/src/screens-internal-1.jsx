// Pantallas internas — parte 1: reservas, detalle, reagendar, reservar, abonos
const { useState: useStateInt1, useMemo: useMemoInt1 } = React;

// ── RESERVAS: listado próximas + pasadas
window.ScreenReservas = ({ go }) => {
  const [tab, setTab] = useStateInt1("proximas");
  const list = tab === "proximas" ? MOCK.proximas : MOCK.pasadas;

  return (
    <div style={{ background: C.bg, color: C.t1, minHeight: "100%", paddingBottom: 110 }}>
      <AppHeader title="Mis turnos" />

      {/* Tabs pill */}
      <div style={{ padding: "8px 20px 14px" }}>
        <div style={{ background: C.bgCard, border: `1px solid ${C.border}`, borderRadius: 14, padding: 4, display: "flex" }}>
          {[["proximas", "Próximos", MOCK.proximas.length], ["pasadas", "Historial", MOCK.pasadas.length]].map(([id, lbl, n]) => (
            <button key={id} onClick={() => setTab(id)} style={{
              flex: 1,
              padding: "10px 14px",
              background: tab === id ? `linear-gradient(135deg, ${C.coral}, ${C.coralD})` : "transparent",
              color: tab === id ? "#fff" : C.t2,
              border: "none",
              borderRadius: 10,
              fontSize: 13,
              fontWeight: 700,
              cursor: "pointer",
              fontFamily: "inherit",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              gap: 6,
              boxShadow: tab === id ? "0 4px 12px rgba(224,91,40,0.3)" : "none",
            }}>
              {lbl}
              <span style={{
                background: tab === id ? "rgba(255,255,255,0.25)" : C.bgElev,
                color: tab === id ? "#fff" : C.t3,
                padding: "1px 7px",
                borderRadius: 100,
                fontSize: 11,
                fontWeight: 700,
              }}>{n}</span>
            </button>
          ))}
        </div>
      </div>

      <div style={{ padding: "0 20px", display: "flex", flexDirection: "column", gap: 10 }}>
        {list.length === 0 && (
          <div style={{ textAlign: "center", padding: "60px 20px", color: C.t3 }}>
            <div style={{ fontSize: 36, marginBottom: 10 }}>📅</div>
            <div style={{ fontSize: 14 }}>No tenés turnos por acá todavía</div>
          </div>
        )}
        {list.map(t => (
          <div key={t.id} onClick={() => go("reservaDetalle", t)} style={{
            background: C.bgCard,
            border: `1px solid ${C.border}`,
            borderRadius: 18,
            padding: "16px 16px",
            cursor: "pointer",
            display: "flex",
            gap: 14,
            alignItems: "center",
          }}>
            <div style={{
              width: 56,
              height: 64,
              borderRadius: 14,
              background: tab === "pasadas" ? C.bgElev : `linear-gradient(180deg, ${C.coralD}, ${C.coral})`,
              border: tab === "pasadas" ? `1px solid ${C.border}` : "none",
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              justifyContent: "center",
              flexShrink: 0,
              color: "#fff",
            }}>
              <div style={{ fontSize: 9, fontWeight: 700, letterSpacing: 0.5, opacity: 0.85 }}>
                {["DOM","LUN","MAR","MIÉ","JUE","VIE","SÁB"][t.inicio.getDay()]}
              </div>
              <div style={{ fontSize: 22, fontWeight: 800, lineHeight: 1, marginTop: 2 }}>{t.inicio.getDate()}</div>
              <div style={{ fontSize: 9, marginTop: 2, opacity: 0.85, fontWeight: 600 }}>
                {["ENE","FEB","MAR","ABR","MAY","JUN","JUL","AGO","SEP","OCT","NOV","DIC"][t.inicio.getMonth()]}
              </div>
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: 16, fontWeight: 700, color: C.t1, marginBottom: 4, letterSpacing: -0.2 }}>
                {String(t.inicio.getHours()).padStart(2, "0")}:{String(t.inicio.getMinutes()).padStart(2, "0")} · {t.cancha}
              </div>
              <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
                {t.estado === "no_show" && <Badge tone="red">No show</Badge>}
                {t.tipo === "abono" && <Badge tone="purple">Abono</Badge>}
                {t.tipo !== "abono" && !t.pagado && t.pago !== "abono" && <Badge tone="yellow">Por pagar</Badge>}
                {t.estado === "confirmado" && t.tipo !== "abono" && t.pagado && <Badge tone="green">Pagado</Badge>}
                {t.precio > 0 && <Badge tone="gray">{fmtGs(t.precio)}</Badge>}
              </div>
            </div>
            <Icons.ChevronRight size={18} color={C.t3} />
          </div>
        ))}
      </div>
    </div>
  );
};

// ── DETALLE de reserva
window.ScreenReservaDetalle = ({ go, back, turno }) => {
  const isAbono = turno.tipo === "abono";
  const isPending = !turno.pagado && turno.pago !== "abono";
  const horasFalta = (turno.inicio.getTime() - Date.now()) / 3600000;
  const puedeReagendar = horasFalta >= 12 && !isAbono;
  const puedeCancelar = horasFalta >= 12 && !isAbono;

  return (
    <div style={{ background: C.bg, color: C.t1, minHeight: "100%", paddingBottom: 30 }}>
      <AppHeader title="Detalle del turno" onBack={back} />

      <div style={{ padding: "8px 20px 20px" }}>
        <div style={{
          background: `linear-gradient(160deg, ${C.coralD} 0%, ${C.coral} 100%)`,
          borderRadius: 22,
          padding: "22px 22px 22px",
          color: "#fff",
          marginBottom: 16,
          position: "relative",
          overflow: "hidden",
          boxShadow: "0 14px 36px rgba(224,91,40,0.3)",
        }}>
          <div style={{ position: "absolute", right: -50, top: -40, width: 180, height: 180, borderRadius: "50%", background: "rgba(255,255,255,0.08)" }} />
          <div style={{ position: "relative", fontSize: 11, fontWeight: 700, letterSpacing: 2, textTransform: "uppercase", opacity: 0.95, marginBottom: 8 }}>
            {fmtFecha(turno.inicio)}
          </div>
          <div style={{ position: "relative", fontSize: 56, fontWeight: 800, lineHeight: 1, letterSpacing: -2, marginBottom: 10 }}>
            {String(turno.inicio.getHours()).padStart(2, "0")}:{String(turno.inicio.getMinutes()).padStart(2, "0")}
          </div>
          <div style={{ position: "relative", fontSize: 14, opacity: 0.95, display: "flex", alignItems: "center", gap: 6 }}>
            <Icons.MapPin size={14} /> {turno.cancha} · {turno.duracion} minutos
          </div>
        </div>

        {/* Estado */}
        <Card style={{ marginBottom: 12 }}>
          <Row label="Estado">
            {isAbono ? <Badge tone="purple">Abono</Badge> :
             isPending ? <Badge tone="yellow">Pendiente de pago</Badge> :
             <Badge tone="green">Confirmado</Badge>}
          </Row>
          <Row label="Pago">
            <span style={{ color: C.t1, fontSize: 13, fontWeight: 600 }}>
              {turno.pago === "abono" ? "Incluido en abono" :
               turno.pago === "transferencia" ? "Transferencia bancaria" :
               "Pagopar (online)"}
            </span>
          </Row>
          {turno.precio > 0 && (
            <Row label="Precio">
              <span style={{ color: C.t1, fontSize: 15, fontWeight: 700 }}>{fmtGs(turno.precio)}</span>
            </Row>
          )}
          <Row label="Código">
            <span style={{ color: C.t2, fontSize: 12, fontFamily: "ui-monospace, monospace" }}>{turno.id.toUpperCase()}</span>
          </Row>
        </Card>

        {/* Política */}
        <Card style={{ marginBottom: 16, background: C.coralAlpha, border: `1px solid ${C.coral}33` }}>
          <div style={{ display: "flex", alignItems: "flex-start", gap: 10 }}>
            <div style={{ color: C.coral, marginTop: 1 }}><Icons.Clock size={18} /></div>
            <div>
              <div style={{ fontSize: 13, fontWeight: 700, color: C.t1, marginBottom: 4 }}>Política de reagendamiento</div>
              <div style={{ fontSize: 12, color: C.t2, lineHeight: 1.5 }}>
                Podés reagendar o cancelar sin costo hasta <b style={{ color: C.t1 }}>12 horas antes</b> del turno.
                {!puedeReagendar && !isAbono && <span style={{ color: C.yellow }}> Ya no estás a tiempo — escribinos por WhatsApp.</span>}
              </div>
            </div>
          </div>
        </Card>

        {isPending && (
          <Btn full size="lg" style={{ marginBottom: 10 }} icon={<Icons.Wallet />}>
            Pagar ahora — {fmtGs(turno.precio)}
          </Btn>
        )}

        {puedeReagendar && (
          <Btn full size="lg" variant="ghost" style={{ marginBottom: 10 }} icon={<Icons.RotateCcw />} onClick={() => go("reagendar", turno)}>
            Reagendar turno
          </Btn>
        )}

        {puedeCancelar && (
          <Btn full size="md" variant="danger" icon={<Icons.Trash />}>
            Cancelar turno
          </Btn>
        )}

        <button style={{
          background: "none",
          border: "none",
          color: C.t2,
          fontSize: 13,
          fontFamily: "inherit",
          cursor: "pointer",
          padding: "16px 0 0",
          width: "100%",
          textAlign: "center",
          display: "inline-flex",
          alignItems: "center",
          justifyContent: "center",
          gap: 6,
          textDecoration: "underline",
        }}>
          <Icons.Whatsapp size={14} /> Escribir al club
        </button>
      </div>
    </div>
  );
};

const Row = ({ label, children }) => (
  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "8px 0", borderBottom: `1px solid ${C.border}` }}>
    <span style={{ fontSize: 12, color: C.t2, fontWeight: 600 }}>{label}</span>
    <div>{children}</div>
  </div>
);

// ── REAGENDAR: elegir nuevo slot
window.ScreenReagendar = ({ go, back, turno, showToast }) => {
  const [dayIdx, setDayIdx] = useStateInt1(0);
  const [selected, setSelected] = useStateInt1(null);

  const dias = useMemoInt1(() => {
    const arr = [];
    for (let i = 1; i <= 7; i++) {
      const x = new Date();
      x.setHours(0, 0, 0, 0);
      x.setDate(x.getDate() + i);
      arr.push(x);
    }
    return arr;
  }, []);

  const slotsDia = useMemoInt1(() => {
    const d = dias[dayIdx];
    return MOCK.slots.filter(s => {
      const sd = new Date(s.inicio);
      return sd.getDate() === d.getDate() && sd.getMonth() === d.getMonth();
    });
  }, [dayIdx]);

  const confirm = () => {
    showToast("Turno reagendado correctamente");
    back();
  };

  return (
    <div style={{ background: C.bg, color: C.t1, minHeight: "100%", display: "flex", flexDirection: "column" }}>
      <AppHeader title="Reagendar turno" onBack={back} subtitle={`Original: ${fmtCorto(turno.inicio)} ${String(turno.inicio.getHours()).padStart(2, "0")}:00`} />

      {/* Selector días */}
      <div style={{ padding: "8px 0 12px", overflowX: "auto" }}>
        <div style={{ display: "flex", gap: 8, padding: "0 20px" }}>
          {dias.map((d, i) => (
            <button key={i} onClick={() => { setDayIdx(i); setSelected(null); }} style={{
              flexShrink: 0,
              padding: "10px 12px",
              background: dayIdx === i ? `linear-gradient(135deg, ${C.coral}, ${C.coralD})` : C.bgCard,
              border: `1px solid ${dayIdx === i ? "transparent" : C.border}`,
              borderRadius: 14,
              color: dayIdx === i ? "#fff" : C.t1,
              fontFamily: "inherit",
              cursor: "pointer",
              minWidth: 60,
              boxShadow: dayIdx === i ? "0 6px 16px rgba(224,91,40,0.3)" : "none",
            }}>
              <div style={{ fontSize: 10, fontWeight: 700, opacity: dayIdx === i ? 0.9 : 0.7, textTransform: "uppercase", letterSpacing: 0.5 }}>
                {["DOM","LUN","MAR","MIÉ","JUE","VIE","SÁB"][d.getDay()]}
              </div>
              <div style={{ fontSize: 20, fontWeight: 800, lineHeight: 1, marginTop: 2 }}>{d.getDate()}</div>
            </button>
          ))}
        </div>
      </div>

      <div style={{ padding: "0 20px 8px" }}>
        <div style={{ fontSize: 13, fontWeight: 700, color: C.t2, letterSpacing: 0.5, textTransform: "uppercase", marginBottom: 12 }}>
          Horarios disponibles
        </div>
      </div>

      <div style={{ flex: 1, padding: "0 20px 120px", display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 8 }}>
        {slotsDia.map(s => {
          const hour = new Date(s.inicio).getHours();
          const isSelected = selected === s.id;
          const isDisabled = !s.disponible;
          return (
            <button
              key={s.id}
              onClick={() => !isDisabled && setSelected(s.id)}
              disabled={isDisabled}
              style={{
                padding: "12px 6px",
                background: isSelected ? `linear-gradient(135deg, ${C.coral}, ${C.coralD})` : (isDisabled ? "transparent" : C.bgCard),
                border: `1px solid ${isSelected ? "transparent" : (isDisabled ? "transparent" : C.border)}`,
                borderRadius: 12,
                color: isSelected ? "#fff" : (isDisabled ? C.t3 : C.t1),
                cursor: isDisabled ? "not-allowed" : "pointer",
                fontFamily: "inherit",
                fontSize: 15,
                fontWeight: 700,
                textDecoration: isDisabled ? "line-through" : "none",
                opacity: isDisabled ? 0.4 : 1,
                boxShadow: isSelected ? "0 6px 16px rgba(224,91,40,0.3)" : "none",
              }}
            >
              {String(hour).padStart(2, "0")}:00
              {s.descuento > 0 && !isDisabled && (
                <div style={{ fontSize: 9, fontWeight: 700, color: isSelected ? "#fff" : C.coral, marginTop: 2 }}>
                  -{s.descuento}%
                </div>
              )}
            </button>
          );
        })}
      </div>

      {selected && (
        <div style={{
          position: "sticky",
          bottom: 0,
          padding: "12px 20px 28px",
          background: `linear-gradient(180deg, rgba(6,13,26,0) 0%, ${C.bg} 30%)`,
        }}>
          <Btn full size="lg" onClick={confirm} icon={<Icons.Check />}>
            Confirmar reagendamiento
          </Btn>
        </div>
      )}
    </div>
  );
};

// ── RESERVAR: nuevo turno (mismo selector)
window.ScreenReservar = ({ go, back, showToast }) => {
  const [step, setStep] = useStateInt1(1); // 1=fecha+slot, 2=pago
  const [dayIdx, setDayIdx] = useStateInt1(0);
  const [selected, setSelected] = useStateInt1(null);
  const [duracion, setDuracion] = useStateInt1(60);
  const [metodo, setMetodo] = useStateInt1("pagopar");
  const [refCode, setRefCode] = useStateInt1("");
  const [aplicarDesc, setAplicarDesc] = useStateInt1(false);

  const dias = useMemoInt1(() => {
    const arr = [];
    for (let i = 0; i < 14; i++) {
      const x = new Date();
      x.setHours(0, 0, 0, 0);
      x.setDate(x.getDate() + i);
      arr.push(x);
    }
    return arr;
  }, []);

  const slotsDia = useMemoInt1(() => {
    const d = dias[dayIdx];
    return MOCK.slots.filter(s => {
      const sd = new Date(s.inicio);
      return sd.getDate() === d.getDate() && sd.getMonth() === d.getMonth();
    });
  }, [dayIdx]);

  const slot = useMemoInt1(() => MOCK.slots.find(s => s.id === selected), [selected]);

  if (step === 1) {
    return (
      <div style={{ background: C.bg, color: C.t1, minHeight: "100%", display: "flex", flexDirection: "column" }}>
        <AppHeader title="Reservar turno" onBack={back} />

        <div style={{ padding: "8px 20px 12px" }}>
          <div style={{ fontSize: 12, color: C.t2, fontWeight: 600, marginBottom: 8 }}>Duración</div>
          <div style={{ display: "flex", gap: 8 }}>
            {[60, 90, 120].map(d => (
              <button key={d} onClick={() => setDuracion(d)} style={{
                flex: 1,
                padding: "12px 8px",
                background: duracion === d ? C.coralAlpha : C.bgCard,
                border: `1px solid ${duracion === d ? C.coral : C.border}`,
                borderRadius: 12,
                color: duracion === d ? C.coral : C.t1,
                fontFamily: "inherit",
                cursor: "pointer",
                fontWeight: 700,
                fontSize: 13,
              }}>{d} min</button>
            ))}
          </div>
        </div>

        <div style={{ padding: "8px 0 12px", overflowX: "auto" }}>
          <div style={{ display: "flex", gap: 8, padding: "0 20px" }}>
            {dias.map((d, i) => (
              <button key={i} onClick={() => { setDayIdx(i); setSelected(null); }} style={{
                flexShrink: 0,
                padding: "10px 12px",
                background: dayIdx === i ? `linear-gradient(135deg, ${C.coral}, ${C.coralD})` : C.bgCard,
                border: `1px solid ${dayIdx === i ? "transparent" : C.border}`,
                borderRadius: 14,
                color: dayIdx === i ? "#fff" : C.t1,
                fontFamily: "inherit",
                cursor: "pointer",
                minWidth: 60,
              }}>
                <div style={{ fontSize: 10, fontWeight: 700, opacity: 0.85, textTransform: "uppercase", letterSpacing: 0.5 }}>
                  {i === 0 ? "HOY" : ["DOM","LUN","MAR","MIÉ","JUE","VIE","SÁB"][d.getDay()]}
                </div>
                <div style={{ fontSize: 20, fontWeight: 800, lineHeight: 1, marginTop: 2 }}>{d.getDate()}</div>
              </button>
            ))}
          </div>
        </div>

        <div style={{ padding: "0 20px 8px" }}>
          <div style={{ fontSize: 13, fontWeight: 700, color: C.t2, letterSpacing: 0.5, textTransform: "uppercase", marginBottom: 12 }}>
            Horarios libres
          </div>
        </div>

        <div style={{ flex: 1, padding: "0 20px 120px", display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 8 }}>
          {slotsDia.length === 0 && (
            <div style={{ gridColumn: "1 / -1", textAlign: "center", padding: "40px 20px", color: C.t3, fontSize: 13 }}>
              No hay horarios cargados para este día.
            </div>
          )}
          {slotsDia.map(s => {
            const hour = new Date(s.inicio).getHours();
            const isSelected = selected === s.id;
            const isDisabled = !s.disponible;
            return (
              <button
                key={s.id}
                onClick={() => !isDisabled && setSelected(s.id)}
                disabled={isDisabled}
                style={{
                  padding: "14px 6px",
                  background: isSelected ? `linear-gradient(135deg, ${C.coral}, ${C.coralD})` : (isDisabled ? "transparent" : C.bgCard),
                  border: `1px solid ${isSelected ? "transparent" : (isDisabled ? "transparent" : C.border)}`,
                  borderRadius: 12,
                  color: isSelected ? "#fff" : (isDisabled ? C.t3 : C.t1),
                  cursor: isDisabled ? "not-allowed" : "pointer",
                  fontFamily: "inherit",
                  fontSize: 15,
                  fontWeight: 700,
                  textDecoration: isDisabled ? "line-through" : "none",
                  opacity: isDisabled ? 0.4 : 1,
                }}
              >
                {String(hour).padStart(2, "0")}:00
                <div style={{ fontSize: 10, color: isSelected ? "#fff" : C.t3, marginTop: 3, fontWeight: 500 }}>
                  {fmtGs(s.precio)}
                </div>
              </button>
            );
          })}
        </div>

        {selected && (
          <div style={{ position: "sticky", bottom: 0, padding: "12px 20px 28px", background: `linear-gradient(180deg, rgba(6,13,26,0) 0%, ${C.bg} 30%)` }}>
            <Btn full size="lg" onClick={() => setStep(2)} icon={<Icons.ArrowRight />}>
              Continuar — {fmtGs(slot?.precio || 0)}
            </Btn>
          </div>
        )}
      </div>
    );
  }

  // step 2 — pago
  const dia = new Date(slot.inicio);
  const isDescDay = dia.getDay() === 2 || dia.getDay() === 4;
  const precioFinal = aplicarDesc && isDescDay ? Math.round(slot.precio * 0.8) : slot.precio;

  return (
    <div style={{ background: C.bg, color: C.t1, minHeight: "100%" }}>
      <AppHeader title="Confirmar y pagar" onBack={() => setStep(1)} />
      <div style={{ padding: "8px 20px 30px" }}>
        <Card style={{ marginBottom: 14 }}>
          <Row label="Día">{fmtFecha(dia)}</Row>
          <Row label="Hora">{String(dia.getHours()).padStart(2, "0")}:00</Row>
          <Row label="Duración">{duracion} minutos</Row>
          <Row label="Cancha">{slot.cancha}</Row>
        </Card>

        {isDescDay && (
          <div onClick={() => setAplicarDesc(!aplicarDesc)} style={{
            background: aplicarDesc ? C.coralAlpha : C.bgCard,
            border: `1px solid ${aplicarDesc ? C.coral : C.border}`,
            borderRadius: 14,
            padding: "14px 16px",
            marginBottom: 14,
            cursor: "pointer",
            display: "flex",
            alignItems: "center",
            gap: 12,
          }}>
            <div style={{
              width: 24,
              height: 24,
              borderRadius: 8,
              border: `2px solid ${aplicarDesc ? C.coral : C.border}`,
              background: aplicarDesc ? C.coral : "transparent",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              color: "#fff",
              flexShrink: 0,
            }}>
              {aplicarDesc && <Icons.Check size={14} />}
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 13, fontWeight: 700, color: C.t1 }}>Aplicar 20% de descuento</div>
              <div style={{ fontSize: 11, color: C.t2 }}>Disponible martes y jueves</div>
            </div>
            <div style={{ fontWeight: 700, color: aplicarDesc ? C.coral : C.t2, fontSize: 14 }}>−{fmtGs(Math.round(slot.precio * 0.2))}</div>
          </div>
        )}

        <div style={{ marginBottom: 14 }}>
          <div style={{ fontSize: 12, color: C.t2, fontWeight: 600, marginBottom: 8 }}>Método de pago</div>
          <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            {[
              ["pagopar", "Pagopar", "Tarjeta / saldo", <Icons.Wallet />],
              ["transferencia", "Transferencia bancaria", "Subís el comprobante", <Icons.ArrowRight />],
            ].map(([id, lbl, sub, ic]) => (
              <div key={id} onClick={() => setMetodo(id)} style={{
                background: metodo === id ? C.coralAlpha : C.bgCard,
                border: `1px solid ${metodo === id ? C.coral : C.border}`,
                borderRadius: 14,
                padding: "14px 16px",
                cursor: "pointer",
                display: "flex",
                alignItems: "center",
                gap: 12,
              }}>
                <div style={{ color: metodo === id ? C.coral : C.t2 }}>{React.cloneElement(ic, { size: 20 })}</div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 14, fontWeight: 700, color: C.t1 }}>{lbl}</div>
                  <div style={{ fontSize: 11, color: C.t2 }}>{sub}</div>
                </div>
                <div style={{
                  width: 20,
                  height: 20,
                  borderRadius: "50%",
                  border: `2px solid ${metodo === id ? C.coral : C.border}`,
                  background: metodo === id ? C.coral : "transparent",
                }} />
              </div>
            ))}
          </div>
        </div>

        <div style={{ marginBottom: 18 }}>
          <div style={{ fontSize: 12, color: C.t2, fontWeight: 600, marginBottom: 8 }}>Código de referido <span style={{ color: C.t3, fontWeight: 400 }}>(opcional)</span></div>
          <input value={refCode} onChange={e => setRefCode(e.target.value.toUpperCase())} placeholder="REF-XXXXXXXX" style={inpStyle} />
        </div>

        <div style={{ background: C.bgCard, border: `1px solid ${C.border}`, borderRadius: 16, padding: "16px 18px", marginBottom: 16 }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <span style={{ fontSize: 13, color: C.t2 }}>Total a pagar</span>
            <span style={{ fontSize: 22, fontWeight: 800, color: C.t1, letterSpacing: -0.5 }}>{fmtGs(precioFinal)}</span>
          </div>
        </div>

        <Btn full size="lg" icon={<Icons.Check />} onClick={() => { showToast("¡Turno reservado! Te llega confirmación por WhatsApp"); back(); }}>
          Confirmar y reservar
        </Btn>
      </div>
    </div>
  );
};

// ── ABONOS / membresía
window.ScreenAbonos = ({ go, back }) => {
  const { cliente } = MOCK;
  return (
    <div style={{ background: C.bg, color: C.t1, minHeight: "100%" }}>
      <AppHeader title="Mi abono" onBack={back} />
      <div style={{ padding: "8px 20px 30px" }}>
        <div style={{
          background: `linear-gradient(135deg, #2A1A60 0%, #120A30 100%)`,
          border: `1px solid ${C.purpleBd}`,
          borderRadius: 22,
          padding: "22px 22px",
          marginBottom: 16,
          position: "relative",
          overflow: "hidden",
        }}>
          <div style={{ position: "absolute", right: -50, top: -50, width: 180, height: 180, borderRadius: "50%", background: "rgba(160,128,255,0.15)" }} />
          <div style={{ position: "relative", display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 16 }}>
            <div>
              <Badge tone="purple">Activo</Badge>
              <div style={{ fontSize: 22, fontWeight: 800, color: C.t1, marginTop: 8, letterSpacing: -0.3 }}>Abono semanal</div>
              <div style={{ fontSize: 13, color: C.t2, marginTop: 2 }}>{cliente.abonoDiaHora} fijo</div>
            </div>
            <div style={{ width: 44, height: 44, borderRadius: 14, background: `linear-gradient(135deg, ${C.purple}, #5A40CC)`, display: "flex", alignItems: "center", justifyContent: "center", color: "#fff" }}>
              <Icons.Crown size={22} />
            </div>
          </div>
          <Row label="Renueva">
            <span style={{ color: C.t1, fontSize: 13, fontWeight: 700 }}>{fmtCorto(cliente.abonoHasta)}</span>
          </Row>
          <Row label="Próximo cobro">
            <span style={{ color: C.t1, fontSize: 13, fontWeight: 700 }}>{fmtGs(320000)}</span>
          </Row>
          <Row label="Turnos restantes">
            <span style={{ color: C.t1, fontSize: 13, fontWeight: 700 }}>4 de 4</span>
          </Row>
        </div>

        <Card style={{ marginBottom: 12 }}>
          <div style={{ display: "flex", alignItems: "flex-start", gap: 10 }}>
            <div style={{ color: C.purple }}><Icons.Sparkle size={18} /></div>
            <div>
              <div style={{ fontSize: 13, fontWeight: 700, color: C.t1, marginBottom: 4 }}>Beneficios del abono</div>
              <ul style={{ fontSize: 12, color: C.t2, lineHeight: 1.7, margin: 0, paddingLeft: 16 }}>
                <li>Tu cancha y horario reservados toda la temporada</li>
                <li>20% off en turnos extra martes y jueves</li>
                <li>Prioridad para inscripción en torneos internos</li>
              </ul>
            </div>
          </div>
        </Card>

        <Btn full size="md" variant="ghost" icon={<Icons.Whatsapp />}>Pausar o cancelar abono</Btn>
      </div>
    </div>
  );
};
