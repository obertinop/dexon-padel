// Pantallas de autenticación: login (teléfono), verify (código), register (alta nueva)
const { useState: useStateAuth, useEffect: useEffectAuth, useRef: useRefAuth } = React;

// ── LOGIN: input teléfono
window.ScreenLogin = ({ onSent, onAdmin }) => {
  const [tel, setTel] = useStateAuth("0994 821 477");
  const [loading, setLoading] = useStateAuth(false);

  const submit = () => {
    if (tel.replace(/\D/g, "").length < 8) return;
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      onSent(tel);
    }, 700);
  };

  return (
    <div style={{
      minHeight: "100%",
      background: `radial-gradient(ellipse 80% 60% at 50% 0%, rgba(224,91,40,0.18) 0%, ${C.bg} 60%)`,
      color: C.t1,
      padding: "70px 24px 40px",
      display: "flex",
      flexDirection: "column",
    }}>
      <div style={{ textAlign: "center", marginBottom: 36 }}>
        <LogoText size={26} />
        <div style={{ marginTop: 6, fontSize: 10, color: C.t3, letterSpacing: 3, textTransform: "uppercase", fontWeight: 600 }}>
          Tavapy · Alto Paraná
        </div>
      </div>

      <div style={{ flex: 1, display: "flex", flexDirection: "column", justifyContent: "center" }}>
        <h1 style={{ fontSize: 30, fontWeight: 800, margin: "0 0 12px", letterSpacing: -1, lineHeight: 1.1 }}>
          Tu cancha,<br/><span style={{ color: C.coral }}>tu cuenta.</span>
        </h1>
        <p style={{ fontSize: 14, color: C.t2, lineHeight: 1.6, marginBottom: 28 }}>
          Ingresá tu número de WhatsApp y te enviamos un código para entrar.
        </p>

        <label style={{ fontSize: 12, color: C.t2, fontWeight: 600, marginBottom: 8, display: "block" }}>WhatsApp</label>
        <div style={{
          display: "flex",
          alignItems: "center",
          background: "rgba(255,255,255,0.04)",
          border: `1px solid ${C.border}`,
          borderRadius: 14,
          padding: "4px 4px 4px 14px",
          marginBottom: 6,
        }}>
          <div style={{ display: "flex", alignItems: "center", gap: 6, color: C.t2, fontSize: 14, fontWeight: 600, paddingRight: 10, borderRight: `1px solid ${C.border}` }}>
            🇵🇾 +595
          </div>
          <input
            value={tel}
            onChange={e => setTel(e.target.value)}
            placeholder="0994 821 477"
            inputMode="tel"
            style={{
              flex: 1,
              padding: "16px 14px",
              background: "transparent",
              border: "none",
              color: C.t1,
              fontSize: 16,
              fontFamily: "inherit",
              outline: "none",
              fontWeight: 500,
              letterSpacing: 0.5,
            }}
          />
        </div>
        <div style={{ fontSize: 11, color: C.t3, marginBottom: 28, paddingLeft: 4 }}>
          Te enviamos un código por WhatsApp (template <code style={{ background: C.bgElev, padding: "1px 6px", borderRadius: 4 }}>dexon_codigo</code>)
        </div>

        <Btn full size="lg" onClick={submit} disabled={loading}>
          {loading ? "Enviando código…" : "Continuar"}
          {!loading && <Icons.ArrowRight />}
        </Btn>

        <div style={{ marginTop: 18, fontSize: 12, color: C.t3, textAlign: "center", lineHeight: 1.5 }}>
          Al continuar aceptás nuestros <span style={{ color: C.t2, textDecoration: "underline" }}>Términos</span> y la <span style={{ color: C.t2, textDecoration: "underline" }}>Política de privacidad</span>.
        </div>
      </div>

      <button onClick={onAdmin} style={{
        background: "none",
        border: "none",
        color: C.t3,
        fontSize: 12,
        textAlign: "center",
        marginTop: 28,
        cursor: "pointer",
        fontFamily: "inherit",
      }}>
        ¿Sos administrador? Acceso staff →
      </button>
    </div>
  );
};

// ── VERIFY: 6 dígitos OTP
window.ScreenVerify = ({ tel, onVerified, onBack, firstTime }) => {
  const [code, setCode] = useStateAuth(["", "", "", "", "", ""]);
  const [seconds, setSeconds] = useStateAuth(45);
  const [error, setError] = useStateAuth("");
  const refs = useRefAuth([...Array(6)].map(() => React.createRef()));

  useEffectAuth(() => {
    if (seconds <= 0) return;
    const i = setInterval(() => setSeconds(s => s - 1), 1000);
    return () => clearInterval(i);
  }, [seconds]);

  const setDigit = (i, v) => {
    if (v && !/^\d$/.test(v)) return;
    const nc = [...code];
    nc[i] = v;
    setCode(nc);
    setError("");
    if (v && i < 5) refs.current[i + 1].current?.focus();
    if (nc.every(d => d !== "")) {
      // Auto-submit
      setTimeout(() => {
        if (nc.join("") === "000000") {
          setError("Código incorrecto");
        } else {
          onVerified();
        }
      }, 250);
    }
  };

  const handleKey = (i, e) => {
    if (e.key === "Backspace" && !code[i] && i > 0) refs.current[i - 1].current?.focus();
  };

  const fillDemo = () => {
    setCode("482915".split(""));
    setTimeout(onVerified, 400);
  };

  return (
    <div style={{
      minHeight: "100%",
      background: C.bg,
      color: C.t1,
      padding: "60px 24px 40px",
      display: "flex",
      flexDirection: "column",
    }}>
      <button onClick={onBack} style={{
        background: C.bgElev,
        border: `1px solid ${C.border}`,
        width: 40,
        height: 40,
        borderRadius: 12,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        color: C.t1,
        cursor: "pointer",
        marginBottom: 32,
      }}>
        <Icons.ArrowLeft size={18} />
      </button>

      <div style={{
        width: 64,
        height: 64,
        borderRadius: 18,
        background: "rgba(37,211,102,0.12)",
        border: "1px solid rgba(37,211,102,0.3)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        color: "#25D366",
        marginBottom: 20,
      }}>
        <Icons.Whatsapp size={30} />
      </div>

      <h1 style={{ fontSize: 26, fontWeight: 800, margin: "0 0 10px", letterSpacing: -0.5, lineHeight: 1.2 }}>
        Ingresá el código
      </h1>
      <p style={{ fontSize: 14, color: C.t2, lineHeight: 1.6, marginBottom: 32 }}>
        Te enviamos un código de 6 dígitos por WhatsApp al <span style={{ color: C.t1, fontWeight: 600 }}>+595 {tel}</span>.
      </p>

      <div style={{ display: "flex", gap: 8, marginBottom: 18 }}>
        {code.map((d, i) => (
          <input
            key={i}
            ref={refs.current[i]}
            value={d}
            onChange={e => setDigit(i, e.target.value.slice(-1))}
            onKeyDown={e => handleKey(i, e)}
            inputMode="numeric"
            maxLength={1}
            autoFocus={i === 0}
            style={{
              flex: 1,
              height: 56,
              textAlign: "center",
              fontSize: 24,
              fontWeight: 700,
              background: d ? C.coralAlpha : "rgba(255,255,255,0.04)",
              border: `1.5px solid ${d ? C.coral : (error ? C.redBd : C.border)}`,
              borderRadius: 14,
              color: C.t1,
              fontFamily: "inherit",
              outline: "none",
              transition: "all 0.15s",
              minWidth: 0,
            }}
          />
        ))}
      </div>

      {error && (
        <div style={{ background: C.redBg, border: `1px solid ${C.redBd}`, color: C.red, padding: "10px 14px", borderRadius: 10, fontSize: 13, marginBottom: 14 }}>
          {error}. ¿Mirá tu WhatsApp e intentá de nuevo.
        </div>
      )}

      <div style={{ fontSize: 13, color: C.t2, marginBottom: 28 }}>
        {seconds > 0 ? (
          <span>Podés reenviarlo en <span style={{ color: C.t1, fontWeight: 600 }}>{seconds}s</span></span>
        ) : (
          <button onClick={() => setSeconds(45)} style={{ background: "none", border: "none", color: C.coral, fontSize: 13, fontWeight: 600, cursor: "pointer", padding: 0, fontFamily: "inherit" }}>
            Reenviar código →
          </button>
        )}
      </div>

      <div style={{ marginTop: "auto", padding: "14px 16px", background: C.bgCard, border: `1px dashed ${C.border}`, borderRadius: 12, fontSize: 12, color: C.t3, lineHeight: 1.5 }}>
        💡 <b style={{ color: C.t2 }}>Demo:</b> usá el código <button onClick={fillDemo} style={{ background: "none", border: "none", color: C.coral, fontWeight: 700, cursor: "pointer", padding: 0, fontFamily: "inherit", fontSize: 12 }}>482915</button> · o <button onClick={fillDemo} style={{ background: "none", border: "none", color: C.coral, fontWeight: 700, cursor: "pointer", padding: 0, fontFamily: "inherit", fontSize: 12 }}>autocompletar</button>
      </div>
    </div>
  );
};

// ── REGISTER: alta de cliente nuevo (cuando el tel no existe)
window.ScreenRegister = ({ tel, onDone, onBack }) => {
  const [nombre, setNombre] = useStateAuth("");
  const [apellido, setApellido] = useStateAuth("");
  const [ref, setRef] = useStateAuth("");

  const canSubmit = nombre.trim().length >= 2 && apellido.trim().length >= 2;

  return (
    <div style={{ minHeight: "100%", background: C.bg, color: C.t1, padding: "60px 24px 40px", display: "flex", flexDirection: "column" }}>
      <button onClick={onBack} style={{
        background: C.bgElev,
        border: `1px solid ${C.border}`,
        width: 40,
        height: 40,
        borderRadius: 12,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        color: C.t1,
        cursor: "pointer",
        marginBottom: 28,
      }}>
        <Icons.ArrowLeft size={18} />
      </button>

      <h1 style={{ fontSize: 26, fontWeight: 800, margin: "0 0 10px", letterSpacing: -0.5, lineHeight: 1.2 }}>
        Bienvenido a Dexon
      </h1>
      <p style={{ fontSize: 14, color: C.t2, lineHeight: 1.6, marginBottom: 24 }}>
        Es tu primera vez. Completá unos datos para crear tu cuenta.
      </p>

      <label style={{ fontSize: 12, color: C.t2, fontWeight: 600, marginBottom: 8, display: "block" }}>Nombre</label>
      <input value={nombre} onChange={e => setNombre(e.target.value)} placeholder="Pablo" style={inpStyle} />

      <label style={{ fontSize: 12, color: C.t2, fontWeight: 600, marginBottom: 8, marginTop: 14, display: "block" }}>Apellido</label>
      <input value={apellido} onChange={e => setApellido(e.target.value)} placeholder="Obertino" style={inpStyle} />

      <label style={{ fontSize: 12, color: C.t2, fontWeight: 600, marginBottom: 8, marginTop: 14, display: "block" }}>Código de referido <span style={{ color: C.t3, fontWeight: 400 }}>(opcional)</span></label>
      <input value={ref} onChange={e => setRef(e.target.value.toUpperCase())} placeholder="REF-XXXXXXXX" style={inpStyle} />

      <div style={{ marginTop: 24, padding: "12px 14px", background: C.coralAlpha, border: `1px solid ${C.coral}33`, borderRadius: 12, fontSize: 12, color: C.t2, lineHeight: 1.5, display: "flex", gap: 10, alignItems: "flex-start" }}>
        <span style={{ color: C.coral, marginTop: 1 }}><Icons.Gift size={16} /></span>
        <span>Si te invitó un amigo, ingresá su código y recibí <b style={{ color: C.coral }}>20.000 ₲</b> de saldo a favor en tu primer turno.</span>
      </div>

      <div style={{ marginTop: "auto", paddingTop: 24 }}>
        <Btn full size="lg" disabled={!canSubmit} onClick={onDone}>
          Crear cuenta
          <Icons.ArrowRight />
        </Btn>
      </div>
    </div>
  );
};

const inpStyle = {
  width: "100%",
  padding: "14px 16px",
  background: "rgba(255,255,255,0.04)",
  border: `1px solid ${C.border}`,
  borderRadius: 14,
  color: C.t1,
  fontSize: 15,
  fontFamily: "inherit",
  outline: "none",
  boxSizing: "border-box",
  fontWeight: 500,
};
