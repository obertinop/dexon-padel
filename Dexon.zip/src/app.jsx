// App principal — navegación + tweaks
const { useState: useStateApp, useEffect: useEffectApp } = React;

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "variant": "v2",
  "startScreen": "home"
}/*EDITMODE-END*/;

function MiCuentaApp() {
  const { tweaks: t, setTweak } = useTweaks(TWEAK_DEFAULTS);

  const [stack, setStack] = useStateApp([{ screen: t.startScreen || "home", payload: null }]);
  const [tab, setTab] = useStateApp("home");
  const [toast, setToast] = useStateApp("");
  const [authed, setAuthed] = useStateApp(t.startScreen !== "login" && t.startScreen !== "verify" && t.startScreen !== "register");

  // sync con tweak startScreen
  useEffectApp(() => {
    setStack([{ screen: t.startScreen || "home", payload: null }]);
    setAuthed(t.startScreen !== "login" && t.startScreen !== "verify" && t.startScreen !== "register");
    if (["home", "reservas", "referido", "perfil"].includes(t.startScreen)) setTab(t.startScreen === "home" ? "home" : t.startScreen);
  }, [t.startScreen]);

  const current = stack[stack.length - 1];

  const go = (screen, payload) => {
    if (["home", "reservas", "referido", "perfil"].includes(screen)) {
      // tab change → reset stack
      setTab(screen);
      setStack([{ screen, payload }]);
    } else {
      setStack([...stack, { screen, payload }]);
    }
  };

  const back = () => {
    if (stack.length > 1) setStack(stack.slice(0, -1));
  };

  const onTabChange = (id) => {
    if (id === "reservar") {
      go("reservar");
      return;
    }
    setTab(id);
    setStack([{ screen: id, payload: null }]);
  };

  const showToast = (m) => setToast(m);

  if (!authed) {
    return (
      <>
        {current.screen === "login" && (
          <ScreenLogin
            onSent={(tel) => setStack([{ screen: "verify", payload: { tel } }])}
            onAdmin={() => showToast("→ Redirige al login admin existente")}
          />
        )}
        {current.screen === "verify" && (
          <ScreenVerify
            tel={current.payload?.tel || "0994 821 477"}
            onBack={() => setStack([{ screen: "login" }])}
            onVerified={() => {
              // si es first-time, va a register; aquí simulamos que ya existe
              setAuthed(true);
              setStack([{ screen: "home" }]);
              setTab("home");
              setTimeout(() => showToast("¡Bienvenido de vuelta, Pablo!"), 200);
            }}
          />
        )}
        {current.screen === "register" && (
          <ScreenRegister
            tel={current.payload?.tel || "0994 821 477"}
            onBack={() => setStack([{ screen: "verify", payload: current.payload }])}
            onDone={() => {
              setAuthed(true);
              setStack([{ screen: "home" }]);
              setTab("home");
              setTimeout(() => showToast("¡Cuenta creada! Bienvenido a Dexon"), 200);
            }}
          />
        )}
        <Toast msg={toast} onDone={() => setToast("")} />
      </>
    );
  }

  const Variant = t.variant === "v1" ? DashboardV1 : t.variant === "v3" ? DashboardV3 : DashboardV2;

  const onLogout = () => {
    setAuthed(false);
    setStack([{ screen: "login" }]);
    setTweak("startScreen", "login");
  };

  const renderScreen = () => {
    const s = current.screen;
    const p = current.payload;
    if (s === "home") return <Variant go={go} onLogout={onLogout} />;
    if (s === "reservas") return <ScreenReservas go={go} />;
    if (s === "reservaDetalle") return <ScreenReservaDetalle go={go} back={back} turno={p} />;
    if (s === "reagendar") return <ScreenReagendar go={go} back={back} turno={p} showToast={showToast} />;
    if (s === "reservar") return <ScreenReservar go={go} back={back} showToast={showToast} />;
    if (s === "referido") return <ScreenReferido back={() => { setTab("home"); setStack([{ screen: "home" }]); }} showToast={showToast} />;
    if (s === "perfil") return <ScreenPerfil back={() => { setTab("home"); setStack([{ screen: "home" }]); }} go={go} onLogout={onLogout} showToast={showToast} />;
    if (s === "pagos") return <ScreenPagos back={back} />;
    if (s === "notif") return <ScreenNotif back={back} showToast={showToast} />;
    if (s === "favoritos") return <ScreenFavoritos back={back} go={go} showToast={showToast} />;
    if (s === "abonos") return <ScreenAbonos back={back} />;
    return <Variant go={go} onLogout={onLogout} />;
  };

  // bottom nav solo en pantallas top-level
  const showNav = ["home", "reservas", "referido", "perfil"].includes(current.screen) && stack.length === 1;

  return (
    <>
      <div key={current.screen + stack.length} className="fade-in">{renderScreen()}</div>
      {showNav && <BottomNav active={tab} onChange={onTabChange} />}
      <Toast msg={toast} onDone={() => setToast("")} />

      <TweaksPanel title="Tweaks">
        <TweakSection title="Variante de dashboard">
          <TweakRadio
            value={t.variant}
            onChange={v => setTweak("variant", v)}
            options={[
              { value: "v1", label: "Compacto" },
              { value: "v2", label: "Feed" },
              { value: "v3", label: "Wallet" },
            ]}
          />
          <div style={{ fontSize: 11, color: "rgba(255,255,255,0.55)", marginTop: 6, lineHeight: 1.45 }}>
            {t.variant === "v1" && "Header + hero card + stats grid + accesos rápidos. Compacto y denso."}
            {t.variant === "v2" && "Hero tipo ticket + feed de cards apiladas. Conversacional, app-style."}
            {t.variant === "v3" && "Saldo prominente como wallet + chips. Premium, foco en el dinero."}
          </div>
        </TweakSection>

        <TweakSection title="Salto rápido a pantalla">
          <TweakSelect
            value={t.startScreen}
            onChange={v => setTweak("startScreen", v)}
            options={[
              { value: "login", label: "1 · Login (teléfono)" },
              { value: "verify", label: "2 · Verificar código" },
              { value: "register", label: "3 · Registro (1ª vez)" },
              { value: "home", label: "4 · Dashboard" },
              { value: "reservas", label: "5 · Mis turnos" },
              { value: "reservar", label: "6 · Reservar turno" },
              { value: "referido", label: "7 · Código de referido" },
              { value: "perfil", label: "8 · Mi cuenta" },
              { value: "pagos", label: "9 · Historial pagos" },
              { value: "abonos", label: "10 · Mi abono" },
              { value: "notif", label: "11 · Notificaciones" },
              { value: "favoritos", label: "12 · Favoritos" },
            ]}
          />
        </TweakSection>
      </TweaksPanel>
    </>
  );
}

ReactDOM.createRoot(document.getElementById("app")).render(
  <IOSDevice dark={true} width={402} height={874}>
    <MiCuentaApp />
  </IOSDevice>
);
