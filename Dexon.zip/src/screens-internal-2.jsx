// Pantallas internas — parte 2: referido, perfil, pagos, notif, favoritos
const { useState: useStateInt2 } = React;

// ── REFERIDO
window.ScreenReferido = ({ back, showToast }) => {
  const { cliente, referidosLista } = MOCK;
  const shareText = `Vení a jugar al pádel a Dexon en Tavapy. Reservá con mi código ${cliente.refCode} y me dan ₲ 20.000 de saldo (y vos también si te animás). https://dexon.com.py/reservar`;

  const compartir = () => {
    if (navigator.share) {
      navigator.share({ title: "Dexon Padel", text: shareText }).catch(() => {});
    } else {
      showToast("Código copiado al portapapeles");
    }
  };

  return (
    <div style={{ background: C.bg, color: C.t1, minHeight: "100%" }}>
      <AppHeader title="Invitá amigos" onBack={back} />

      <div style={{ padding: "8px 20px 30px" }}>
        {/* Hero gradient */}
        <div style={{
          background: `linear-gradient(160deg, ${C.coralD} 0%, ${C.coral} 100%)`,
          borderRadius: 22,
          padding: "24px 22px",
          color: "#fff",
          marginBottom: 18,
          position: "relative",
          overflow: "hidden",
          boxShadow: "0 14px 36px rgba(224,91,40,0.3)",
        }}>
          <div style={{ position: "absolute", right: -40, top: -40, width: 180, height: 180, borderRadius: "50%", background: "rgba(255,255,255,0.1)" }} />
          <div style={{ position: "absolute", right: -80, bottom: -80, width: 220, height: 220, borderRadius: "50%", background: "rgba(255,255,255,0.06)" }} />

          <div style={{ position: "relative", display: "flex", alignItems: "center", gap: 10, marginBottom: 14 }}>
            <Icons.Gift size={20} /> <span style={{ fontSize: 11, fontWeight: 700, letterSpacing: 2, textTransform: "uppercase" }}>Programa de referidos</span>
          </div>
          <div style={{ position: "relative", fontSize: 28, fontWeight: 800, letterSpacing: -0.8, lineHeight: 1.15, marginBottom: 10 }}>
            Ganá <span style={{ background: "rgba(255,255,255,0.18)", padding: "0 8px", borderRadius: 8 }}>₲ 20.000</span><br/>
            por cada amigo<br/>que reserve.
          </div>
          <div style={{ position: "relative", fontSize: 13, opacity: 0.95, lineHeight: 1.5 }}>
            Y ellos también, en su primer turno.
          </div>
        </div>

        {/* Código */}
        <div style={{ background: C.bgCard, border: `1.5px dashed ${C.coral}`, borderRadius: 18, padding: "16px 16px", marginBottom: 14 }}>
          <div style={{ fontSize: 11, color: C.t2, fontWeight: 600, letterSpacing: 1, textTransform: "uppercase", marginBottom: 6 }}>Tu código</div>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 10 }}>
            <div style={{ fontSize: 24, fontWeight: 800, color: C.coral, letterSpacing: 1.5, fontFamily: "ui-monospace, monospace" }}>{cliente.refCode}</div>
            <button onClick={() => showToast("Código copiado")} style={{
              background: C.bgElev,
              border: `1px solid ${C.border}`,
              borderRadius: 10,
              padding: "8px 10px",
              color: C.t1,
              cursor: "pointer",
            }}>
              <Icons.Copy size={16} />
            </button>
          </div>
        </div>

        <Btn full size="lg" icon={<Icons.Share />} onClick={compartir}>Compartir con amigos</Btn>

        {/* Stats acumulados */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, margin: "16px 0 18px" }}>
          <Card padding={16}>
            <div style={{ fontSize: 11, color: C.t2, fontWeight: 600, letterSpacing: 1, textTransform: "uppercase", marginBottom: 6 }}>Amigos</div>
            <div style={{ fontSize: 28, fontWeight: 800, color: C.t1, letterSpacing: -0.5 }}>{cliente.referidos}</div>
          </Card>
          <Card padding={16}>
            <div style={{ fontSize: 11, color: C.t2, fontWeight: 600, letterSpacing: 1, textTransform: "uppercase", marginBottom: 6 }}>Saldo acumulado</div>
            <div style={{ fontSize: 22, fontWeight: 800, color: C.coral, letterSpacing: -0.5 }}>{fmtGs(cliente.saldo)}</div>
          </Card>
        </div>

        <div style={{ fontSize: 13, fontWeight: 700, color: C.t2, letterSpacing: 0.5, textTransform: "uppercase", marginBottom: 12 }}>Tus invitados</div>
        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          {referidosLista.map((r, i) => (
            <div key={i} style={{
              background: C.bgCard,
              border: `1px solid ${C.border}`,
              borderRadius: 14,
              padding: "12px 14px",
              display: "flex",
              alignItems: "center",
              gap: 12,
            }}>
              <Avatar nombre={r.nombre} size={36} />
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 14, fontWeight: 700, color: C.t1 }}>{r.nombre}</div>
                <div style={{ fontSize: 11, color: C.t3 }}>{fmtCorto(r.fecha)}</div>
              </div>
              <Badge tone="green">+{fmtGs(r.bono)}</Badge>
            </div>
          ))}
        </div>

        <div style={{ marginTop: 20, padding: "12px 14px", background: C.bgCard, border: `1px solid ${C.border}`, borderRadius: 12, fontSize: 12, color: C.t2, lineHeight: 1.6 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 6, color: C.t1, fontWeight: 700, marginBottom: 4 }}>
            <Icons.Sparkle size={14} /> Cómo funciona
          </div>
          1. Compartís tu código.<br/>
          2. Tu amigo lo usa al reservar su primer turno.<br/>
          3. Recibís ₲ 20.000 de saldo a favor — aplicable en tu próximo turno.
        </div>
      </div>
    </div>
  );
};

// ── PERFIL: datos personales
window.ScreenPerfil = ({ back, onLogout, go, showToast }) => {
  const { cliente } = MOCK;
  const [nombre, setNombre] = useStateInt2(cliente.nombre);
  const [apellido, setApellido] = useStateInt2(cliente.apellido);
  const [email, setEmail] = useStateInt2("");
  const [editing, setEditing] = useStateInt2(false);

  return (
    <div style={{ background: C.bg, color: C.t1, minHeight: "100%", paddingBottom: 110 }}>
      <AppHeader title="Mi cuenta" />

      {/* Avatar grande */}
      <div style={{ padding: "8px 20px 18px", textAlign: "center" }}>
        <div style={{ display: "inline-flex", flexDirection: "column", alignItems: "center", gap: 10 }}>
          <Avatar nombre={cliente.nombre + " " + cliente.apellido} size={84} />
          <div style={{ fontSize: 19, fontWeight: 800, color: C.t1, letterSpacing: -0.3 }}>{cliente.nombre} {cliente.apellido}</div>
          <Badge tone="coral">Cliente desde 2024</Badge>
        </div>
      </div>

      {/* Datos personales */}
      <div style={{ padding: "0 20px 16px" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
          <div style={{ fontSize: 13, fontWeight: 700, color: C.t2, letterSpacing: 0.5, textTransform: "uppercase" }}>Datos personales</div>
          <button onClick={() => setEditing(!editing)} style={{ background: "none", border: "none", color: C.coral, fontSize: 12, fontWeight: 700, cursor: "pointer", fontFamily: "inherit", display: "inline-flex", alignItems: "center", gap: 4 }}>
            {editing ? <><Icons.Check size={14} /> Listo</> : <><Icons.Edit size={14} /> Editar</>}
          </button>
        </div>

        {editing ? (
          <Card>
            <FieldEdit label="Nombre" value={nombre} onChange={setNombre} />
            <FieldEdit label="Apellido" value={apellido} onChange={setApellido} />
            <FieldEdit label="Email" value={email} onChange={setEmail} placeholder="opcional" />
            <FieldEdit label="WhatsApp" value={cliente.telefono} disabled hint="No se puede cambiar — escribinos al club" />
            <Btn full size="md" style={{ marginTop: 10 }} onClick={() => { setEditing(false); showToast("Datos actualizados"); }}>Guardar</Btn>
          </Card>
        ) : (
          <Card>
            <Row label="Nombre"><span style={{ color: C.t1, fontWeight: 600 }}>{cliente.nombre} {cliente.apellido}</span></Row>
            <Row label="WhatsApp"><span style={{ color: C.t1, fontWeight: 600 }}>{cliente.telefono}</span></Row>
            <Row label="Email"><span style={{ color: C.t3, fontWeight: 500 }}>—</span></Row>
            <Row label="Cliente desde"><span style={{ color: C.t1, fontWeight: 600 }}>Mar 2024</span></Row>
          </Card>
        )}
      </div>

      {/* Menu de accesos */}
      <div style={{ padding: "8px 20px 16px" }}>
        <div style={{ fontSize: 13, fontWeight: 700, color: C.t2, letterSpacing: 0.5, textTransform: "uppercase", marginBottom: 10 }}>Mi actividad</div>
        <div style={{ background: C.bgCard, border: `1px solid ${C.border}`, borderRadius: 18, overflow: "hidden" }}>
          <MenuLink icon={<Icons.Calendar />} label="Mis turnos" sub={`${MOCK.proximas.length} próximos`} onClick={() => go("reservas")} />
          <MenuLink icon={<Icons.Crown />} label="Mi abono" sub={cliente.abonoDiaHora} onClick={() => go("abonos")} />
          <MenuLink icon={<Icons.Heart />} label="Mis favoritos" sub={`${MOCK.favoritos.length} horarios`} onClick={() => go("favoritos")} />
          <MenuLink icon={<Icons.Wallet />} label="Historial de pagos" sub={`${MOCK.pagos.length} movimientos`} onClick={() => go("pagos")} last />
        </div>
      </div>

      <div style={{ padding: "0 20px 16px" }}>
        <div style={{ fontSize: 13, fontWeight: 700, color: C.t2, letterSpacing: 0.5, textTransform: "uppercase", marginBottom: 10 }}>Ajustes</div>
        <div style={{ background: C.bgCard, border: `1px solid ${C.border}`, borderRadius: 18, overflow: "hidden" }}>
          <MenuLink icon={<Icons.Bell />} label="Notificaciones" sub="WhatsApp, recordatorios" onClick={() => go("notif")} />
          <MenuLink icon={<Icons.Gift />} label="Código de referido" sub="Compartir e invitar" onClick={() => go("referido")} />
          <MenuLink icon={<Icons.Whatsapp />} label="Contactar al club" sub="WhatsApp directo" last />
        </div>
      </div>

      <div style={{ padding: "0 20px 20px" }}>
        <Btn full variant="danger" size="md" icon={<Icons.Logout />} onClick={onLogout}>
          Cerrar sesión
        </Btn>
        <div style={{ textAlign: "center", color: C.t3, fontSize: 11, marginTop: 16 }}>
          Dexon Padel · v1.0 · Tavapy, Alto Paraná
        </div>
      </div>
    </div>
  );
};

const FieldEdit = ({ label, value, onChange, placeholder, hint, disabled }) => (
  <div style={{ marginBottom: 12 }}>
    <label style={{ fontSize: 11, color: C.t2, fontWeight: 600, display: "block", marginBottom: 6 }}>{label}</label>
    <input
      value={value}
      onChange={e => onChange && onChange(e.target.value)}
      placeholder={placeholder}
      disabled={disabled}
      style={{
        width: "100%",
        padding: "10px 12px",
        background: disabled ? C.bg : "rgba(255,255,255,0.04)",
        border: `1px solid ${C.border}`,
        borderRadius: 10,
        color: disabled ? C.t3 : C.t1,
        fontSize: 14,
        fontFamily: "inherit",
        outline: "none",
        boxSizing: "border-box",
      }}
    />
    {hint && <div style={{ fontSize: 11, color: C.t3, marginTop: 4 }}>{hint}</div>}
  </div>
);

const MenuLink = ({ icon, label, sub, onClick, last }) => (
  <button onClick={onClick} style={{
    width: "100%",
    background: "none",
    border: "none",
    borderBottom: last ? "none" : `1px solid ${C.border}`,
    padding: "14px 16px",
    display: "flex",
    alignItems: "center",
    gap: 14,
    color: C.t1,
    cursor: "pointer",
    fontFamily: "inherit",
    textAlign: "left",
  }}>
    <div style={{
      width: 38,
      height: 38,
      borderRadius: 11,
      background: C.bgElev,
      color: C.coral,
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      flexShrink: 0,
    }}>{React.cloneElement(icon, { size: 18 })}</div>
    <div style={{ flex: 1, minWidth: 0 }}>
      <div style={{ fontSize: 14, fontWeight: 600, color: C.t1 }}>{label}</div>
      <div style={{ fontSize: 11, color: C.t3, marginTop: 2 }}>{sub}</div>
    </div>
    <Icons.ChevronRight size={18} color={C.t3} />
  </button>
);

// ── PAGOS: historial
window.ScreenPagos = ({ back }) => {
  return (
    <div style={{ background: C.bg, color: C.t1, minHeight: "100%" }}>
      <AppHeader title="Historial de pagos" onBack={back} />
      <div style={{ padding: "8px 20px 30px" }}>
        <Card style={{ marginBottom: 14 }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <div>
              <div style={{ fontSize: 11, color: C.t2, fontWeight: 600, letterSpacing: 1, textTransform: "uppercase" }}>Total gastado</div>
              <div style={{ fontSize: 24, fontWeight: 800, color: C.t1, letterSpacing: -0.5, marginTop: 4 }}>
                {fmtGs(MOCK.pagos.reduce((s, p) => s + p.monto, 0))}
              </div>
            </div>
            <div style={{ color: C.coral }}><Icons.Wallet size={32} /></div>
          </div>
        </Card>

        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          {MOCK.pagos.map(p => (
            <div key={p.id} style={{
              background: C.bgCard,
              border: `1px solid ${C.border}`,
              borderRadius: 14,
              padding: "14px 16px",
              display: "flex",
              alignItems: "center",
              gap: 12,
            }}>
              <div style={{
                width: 38,
                height: 38,
                borderRadius: 11,
                background: p.metodo === "Pagopar" ? C.infoBg : C.greenBg,
                color: p.metodo === "Pagopar" ? C.info : C.green,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                flexShrink: 0,
              }}>
                {p.metodo === "Pagopar" ? <Icons.Wallet size={18} /> : <Icons.Check size={18} />}
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 14, fontWeight: 700, color: C.t1, marginBottom: 2, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{p.concepto}</div>
                <div style={{ fontSize: 11, color: C.t3 }}>{fmtCorto(p.fecha)} · {p.metodo}</div>
              </div>
              <div style={{ fontSize: 15, fontWeight: 700, color: C.t1, whiteSpace: "nowrap" }}>{fmtGs(p.monto)}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

// ── NOTIFICACIONES: toggles
window.ScreenNotif = ({ back, showToast }) => {
  const [n, setN] = useStateInt2(MOCK.notif);
  const toggle = (k) => {
    setN({ ...n, [k]: !n[k] });
    showToast("Preferencia actualizada");
  };

  return (
    <div style={{ background: C.bg, color: C.t1, minHeight: "100%" }}>
      <AppHeader title="Notificaciones" onBack={back} />
      <div style={{ padding: "8px 20px 30px" }}>
        <div style={{ fontSize: 12, color: C.t2, lineHeight: 1.5, marginBottom: 16 }}>
          Elegí cómo te avisamos sobre tus turnos, promos y novedades del club.
        </div>

        <div style={{ background: C.bgCard, border: `1px solid ${C.border}`, borderRadius: 18, overflow: "hidden" }}>
          <ToggleRow
            icon={<Icons.Whatsapp />}
            label="Recordatorios de turno"
            sub="Aviso 1h antes por WhatsApp"
            on={n.whatsapp_recordatorio}
            onToggle={() => toggle("whatsapp_recordatorio")}
          />
          <ToggleRow
            icon={<Icons.Sparkle />}
            label="Promos y descuentos"
            sub="Te avisamos cuando hay descuentos especiales"
            on={n.whatsapp_promo}
            onToggle={() => toggle("whatsapp_promo")}
          />
          <ToggleRow
            icon={<Icons.Mail />}
            label="Resumen mensual por email"
            sub="Estadísticas, próximos torneos"
            on={n.email_resumen}
            onToggle={() => toggle("email_resumen")}
          />
          <ToggleRow
            icon={<Icons.Phone />}
            label="Avisos urgentes por SMS"
            sub="Cancelaciones por lluvia, cambios"
            on={n.sms_emergencia}
            onToggle={() => toggle("sms_emergencia")}
            last
          />
        </div>

        <div style={{ marginTop: 18, padding: "12px 14px", background: C.bgCard, border: `1px dashed ${C.border}`, borderRadius: 12, fontSize: 12, color: C.t2, lineHeight: 1.6 }}>
          <div style={{ color: C.t1, fontWeight: 700, marginBottom: 4 }}>📱 Tu WhatsApp registrado</div>
          {MOCK.cliente.telefono} · <button style={{ background: "none", border: "none", color: C.coral, fontWeight: 700, cursor: "pointer", padding: 0, fontFamily: "inherit", fontSize: 12 }}>Cambiar →</button>
        </div>
      </div>
    </div>
  );
};

const ToggleRow = ({ icon, label, sub, on, onToggle, last }) => (
  <div onClick={onToggle} style={{
    padding: "14px 16px",
    borderBottom: last ? "none" : `1px solid ${C.border}`,
    display: "flex",
    alignItems: "center",
    gap: 14,
    cursor: "pointer",
  }}>
    <div style={{
      width: 38,
      height: 38,
      borderRadius: 11,
      background: C.bgElev,
      color: on ? C.coral : C.t3,
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      flexShrink: 0,
    }}>{React.cloneElement(icon, { size: 18 })}</div>
    <div style={{ flex: 1, minWidth: 0 }}>
      <div style={{ fontSize: 14, fontWeight: 600, color: C.t1, marginBottom: 2 }}>{label}</div>
      <div style={{ fontSize: 11, color: C.t3 }}>{sub}</div>
    </div>
    {/* iOS switch */}
    <div style={{
      width: 48,
      height: 28,
      borderRadius: 100,
      background: on ? C.coral : C.bgElev,
      border: `1px solid ${on ? C.coral : C.border}`,
      position: "relative",
      transition: "all 0.2s",
      flexShrink: 0,
    }}>
      <div style={{
        position: "absolute",
        top: 2,
        left: on ? 22 : 2,
        width: 22,
        height: 22,
        borderRadius: "50%",
        background: "#fff",
        boxShadow: "0 2px 4px rgba(0,0,0,0.3)",
        transition: "left 0.2s",
      }} />
    </div>
  </div>
);

// ── FAVORITOS: horarios habituales
window.ScreenFavoritos = ({ back, go, showToast }) => {
  const [items, setItems] = useStateInt2(MOCK.favoritos);

  const remove = (id) => {
    setItems(items.filter(x => x.id !== id));
    showToast("Favorito eliminado");
  };

  return (
    <div style={{ background: C.bg, color: C.t1, minHeight: "100%" }}>
      <AppHeader title="Horarios favoritos" onBack={back} />

      <div style={{ padding: "8px 20px 30px" }}>
        <div style={{ fontSize: 12, color: C.t2, lineHeight: 1.5, marginBottom: 16 }}>
          Tus combos de día + hora habituales — reservalos con un toque cuando estén libres.
        </div>

        <div style={{ display: "flex", flexDirection: "column", gap: 10, marginBottom: 16 }}>
          {items.map(f => (
            <div key={f.id} style={{
              background: C.bgCard,
              border: `1px solid ${C.border}`,
              borderRadius: 18,
              padding: "16px 16px",
              display: "flex",
              gap: 14,
              alignItems: "center",
            }}>
              <div style={{
                width: 48,
                height: 48,
                borderRadius: 14,
                background: C.coralAlpha,
                border: `1px solid ${C.coral}33`,
                color: C.coral,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                flexShrink: 0,
              }}>
                <Icons.Heart size={20} />
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 15, fontWeight: 700, color: C.t1 }}>{f.dia} {f.hora}</div>
                <div style={{ fontSize: 11, color: C.t3, marginTop: 2 }}>{f.label} · {f.duracion}min</div>
              </div>
              <div style={{ display: "flex", gap: 6 }}>
                <button onClick={() => go("reservar")} style={iconBtnSm(C.coral)}>
                  <Icons.Plus size={16} />
                </button>
                <button onClick={() => remove(f.id)} style={iconBtnSm(C.t3)}>
                  <Icons.Trash size={16} />
                </button>
              </div>
            </div>
          ))}
        </div>

        <button style={{
          width: "100%",
          background: "transparent",
          border: `1.5px dashed ${C.border}`,
          borderRadius: 14,
          padding: "16px",
          color: C.t2,
          fontSize: 13,
          fontWeight: 600,
          cursor: "pointer",
          fontFamily: "inherit",
          display: "inline-flex",
          alignItems: "center",
          justifyContent: "center",
          gap: 8,
        }}>
          <Icons.Plus size={16} /> Agregar horario favorito
        </button>
      </div>
    </div>
  );
};

const iconBtnSm = (color) => ({
  background: C.bgElev,
  border: `1px solid ${C.border}`,
  width: 34,
  height: 34,
  borderRadius: 10,
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  color,
  cursor: "pointer",
});
