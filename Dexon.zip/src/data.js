// Mock data — refleja el shape de Supabase del repo (turnos, clientes, etc.)
(function () {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const d = (offsetDays, h) => {
    const x = new Date(today);
    x.setDate(x.getDate() + offsetDays);
    x.setHours(h, 0, 0, 0);
    return x;
  };

  window.MOCK = {
    cliente: {
      id: "c_8a32",
      nombre: "Pablo",
      apellido: "Obertino",
      telefono: "+595 994 821 477",
      telefonoCorto: "0994 821 477",
      refCode: "REF-PABLO24",
      saldo: 60000,
      turnosJugados: 23,
      referidos: 3,
      racha: 4,
      abonado: true,
      abonoDiaHora: "Martes 20:00",
      abonoHasta: d(28, 0),
    },

    proximas: [
      {
        id: "t_001",
        inicio: d(2, 19),
        fin: d(2, 20).setHours(20, 30, 0, 0) && d(2, 20),
        cancha: "Cancha 1",
        duracion: 90,
        precio: 100000,
        estado: "confirmado",
        pago: "transferencia",
        pagado: true,
        tipo: "ocasional",
      },
      {
        id: "t_002",
        inicio: d(5, 20),
        fin: d(5, 21),
        cancha: "Cancha 1",
        duracion: 60,
        precio: 80000,
        estado: "reservado",
        pago: "pagopar",
        pagado: false,
        tipo: "ocasional",
      },
      {
        id: "t_003",
        inicio: d(9, 20),
        fin: d(9, 21),
        cancha: "Cancha 1",
        duracion: 60,
        precio: 0,
        estado: "confirmado",
        pago: "abono",
        pagado: true,
        tipo: "abono",
      },
    ],

    pasadas: [
      { id: "p_01", inicio: d(-5, 19), fin: d(-5, 20), cancha: "Cancha 1", precio: 80000, estado: "confirmado", pago: "transferencia" },
      { id: "p_02", inicio: d(-12, 20), fin: d(-12, 21), cancha: "Cancha 1", precio: 80000, estado: "confirmado", pago: "abono" },
      { id: "p_03", inicio: d(-19, 19), fin: d(-19, 20), cancha: "Cancha 1", precio: 100000, estado: "confirmado", pago: "pagopar" },
      { id: "p_04", inicio: d(-26, 18), fin: d(-26, 19), cancha: "Cancha 1", precio: 80000, estado: "no_show", pago: "transferencia" },
      { id: "p_05", inicio: d(-33, 20), fin: d(-33, 21), cancha: "Cancha 1", precio: 0, estado: "confirmado", pago: "abono" },
    ],

    // Slots disponibles los próximos 7 días — para reagendar / reservar
    slots: (function () {
      const arr = [];
      for (let i = 1; i <= 14; i++) {
        const fecha = d(i, 0);
        const day = fecha.getDay();
        // viernes-domingo desde 10, resto desde 18
        const startHour = day === 0 || day === 6 || day === 5 ? 10 : 18;
        for (let h = startHour; h < 24; h++) {
          // simulamos ocupación: ~50%
          const taken = Math.random() < 0.5;
          arr.push({
            id: `s_${i}_${h}`,
            inicio: d(i, h),
            duracion: 60,
            precio: h >= 18 && h <= 22 ? 100000 : 80000,
            descuento: (day === 2 || day === 4) ? 20 : 0,
            disponible: !taken,
            cancha: "Cancha 1",
          });
        }
      }
      return arr;
    })(),

    pagos: [
      { id: "pg_01", fecha: d(-5, 14), monto: 80000, metodo: "Transferencia", concepto: "Turno Cancha 1 · 19:00", estado: "ok" },
      { id: "pg_02", fecha: d(-12, 9), monto: 320000, metodo: "Pagopar", concepto: "Abono Martes 20:00 · Noviembre", estado: "ok" },
      { id: "pg_03", fecha: d(-19, 18), monto: 100000, metodo: "Pagopar", concepto: "Turno Cancha 1 · 19:00", estado: "ok" },
      { id: "pg_04", fecha: d(-33, 17), monto: 80000, metodo: "Transferencia", concepto: "Turno Cancha 1 · 20:00", estado: "ok" },
      { id: "pg_05", fecha: d(-40, 9), monto: 320000, metodo: "Pagopar", concepto: "Abono Martes 20:00 · Octubre", estado: "ok" },
    ],

    notif: {
      whatsapp_recordatorio: true,
      whatsapp_promo: false,
      email_resumen: false,
      sms_emergencia: true,
    },

    favoritos: [
      { id: "f1", dia: "Martes", hora: "20:00", duracion: 90, label: "Habitual con el grupo" },
      { id: "f2", dia: "Sábado", hora: "10:00", duracion: 60, label: "Sábado familia" },
    ],

    referidosLista: [
      { nombre: "Lucas G.", fecha: d(-30, 0), bono: 20000 },
      { nombre: "Andrea P.", fecha: d(-18, 0), bono: 20000 },
      { nombre: "Diego M.", fecha: d(-7, 0), bono: 20000 },
    ],
  };
})();
