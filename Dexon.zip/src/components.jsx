// Chrome compartido — botones, cards, headers, bottom nav, etc.
const { useState } = React;

// ── Card base
window.Card = ({ children, style = {}, onClick, padding = 18 }) => (
  <div
    onClick={onClick}
    style={{
      background: C.bgCard,
      border: `1px solid ${C.border}`,
      borderRadius: 18,
      padding,
      cursor: onClick ? "pointer" : "default",
      transition: "transform 0.15s, border-color 0.15s",
      ...style,
    }}
  >
    {children}
  </div>
);

// ── Botón
window.Btn = ({ children, onClick, variant = "primary", size = "md", style = {}, icon, full, disabled }) => {
  const sizes = {
    sm: { padding: "8px 14px", fontSize: 13, gap: 6, iconSize: 16 },
    md: { padding: "12px 20px", fontSize: 14, gap: 8, iconSize: 18 },
    lg: { padding: "16px 24px", fontSize: 16, gap: 10, iconSize: 20 },
  }[size];
  const variants = {
    primary: { background: `linear-gradient(135deg, ${C.coral}, ${C.coralD})`, color: "#fff", border: "none", boxShadow: "0 8px 24px rgba(224,91,40,0.35)" },
    ghost: { background: C.bgElev, color: C.t1, border: `1px solid ${C.border}` },
    outline: { background: "transparent", color: C.t1, border: `1px solid ${C.borderL}` },
    danger: { background: C.redBg, color: C.red, border: `1px solid ${C.redBd}` },
    white: { background: "#fff", color: "#0A1525", border: "none" },
    success: { background: C.greenBg, color: C.green, border: `1px solid ${C.greenBd}` },
  }[variant];
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      style={{
        padding: sizes.padding,
        fontSize: sizes.fontSize,
        fontWeight: 600,
        borderRadius: 12,
        cursor: disabled ? "not-allowed" : "pointer",
        opacity: disabled ? 0.5 : 1,
        fontFamily: "inherit",
        display: "inline-flex",
        alignItems: "center",
        justifyContent: "center",
        gap: sizes.gap,
        width: full ? "100%" : undefined,
        transition: "transform 0.1s, opacity 0.15s",
        ...variants,
        ...style,
      }}
    >
      {icon && React.cloneElement(icon, { size: sizes.iconSize })}
      {children}
    </button>
  );
};

// ── Badge
window.Badge = ({ children, tone = "gray" }) => {
  const map = {
    gray: { bg: C.bgElev, fg: C.t2, bd: C.border },
    coral: { bg: "#2A1008", fg: C.coral, bd: "#4A1A08" },
    green: { bg: C.greenBg, fg: C.green, bd: C.greenBd },
    yellow: { bg: C.yellowBg, fg: C.yellow, bd: C.yellowBd },
    red: { bg: C.redBg, fg: C.red, bd: C.redBd },
    purple: { bg: C.purpleBg, fg: C.purple, bd: C.purpleBd },
    info: { bg: C.infoBg, fg: C.info, bd: "#0E2A50" },
  }[tone];
  return (
    <span style={{
      display: "inline-flex",
      alignItems: "center",
      gap: 4,
      background: map.bg,
      color: map.fg,
      border: `1px solid ${map.bd}`,
      borderRadius: 100,
      fontSize: 11,
      padding: "3px 9px",
      fontWeight: 600,
      whiteSpace: "nowrap",
    }}>{children}</span>
  );
};

// ── Header sticky con back
window.AppHeader = ({ title, onBack, right, subtitle, transparent }) => (
  <div style={{
    position: "sticky",
    top: 0,
    background: transparent ? "transparent" : C.bg,
    borderBottom: transparent ? "none" : `1px solid ${C.border}`,
    padding: "12px 20px",
    display: "flex",
    alignItems: "center",
    gap: 12,
    zIndex: 10,
    minHeight: 56,
  }}>
    {onBack && (
      <button onClick={onBack} style={{
        background: C.bgElev,
        border: `1px solid ${C.border}`,
        width: 36,
        height: 36,
        borderRadius: 12,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        color: C.t1,
        cursor: "pointer",
        flexShrink: 0,
      }}>
        <Icons.ArrowLeft size={18} />
      </button>
    )}
    <div style={{ flex: 1, minWidth: 0 }}>
      <div style={{ fontSize: 17, fontWeight: 700, color: C.t1, letterSpacing: -0.2, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{title}</div>
      {subtitle && <div style={{ fontSize: 12, color: C.t2 }}>{subtitle}</div>}
    </div>
    {right}
  </div>
);

// ── Bottom navigation
window.BottomNav = ({ active, onChange }) => {
  const tabs = [
    { id: "home", label: "Inicio", icon: Icons.Home },
    { id: "reservas", label: "Reservas", icon: Icons.Calendar },
    { id: "reservar", label: "Reservar", icon: Icons.Plus, primary: true },
    { id: "referido", label: "Amigos", icon: Icons.Gift },
    { id: "perfil", label: "Cuenta", icon: Icons.User },
  ];
  return (
    <div style={{
      position: "absolute",
      bottom: 0,
      left: 0,
      right: 0,
      paddingBottom: 28,
      background: "linear-gradient(180deg, rgba(6,13,26,0) 0%, rgba(6,13,26,0.95) 30%)",
      pointerEvents: "none",
      zIndex: 20,
    }}>
      <div style={{
        margin: "0 16px",
        background: "rgba(12,22,40,0.92)",
        backdropFilter: "blur(20px)",
        WebkitBackdropFilter: "blur(20px)",
        border: `1px solid ${C.border}`,
        borderRadius: 24,
        padding: "8px 6px",
        display: "flex",
        justifyContent: "space-around",
        alignItems: "center",
        boxShadow: "0 12px 40px rgba(0,0,0,0.5)",
        pointerEvents: "auto",
      }}>
        {tabs.map((t) => {
          const isActive = active === t.id;
          const Icon = t.icon;
          if (t.primary) {
            return (
              <button
                key={t.id}
                onClick={() => onChange(t.id)}
                style={{
                  background: `linear-gradient(135deg, ${C.coral}, ${C.coralD})`,
                  border: "none",
                  width: 50,
                  height: 50,
                  borderRadius: 16,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  color: "#fff",
                  cursor: "pointer",
                  boxShadow: "0 8px 20px rgba(224,91,40,0.4)",
                  transform: "translateY(-8px)",
                }}
                aria-label={t.label}
              >
                <Icon size={24} />
              </button>
            );
          }
          return (
            <button
              key={t.id}
              onClick={() => onChange(t.id)}
              style={{
                background: "none",
                border: "none",
                flex: 1,
                padding: "8px 4px",
                color: isActive ? C.coral : C.t3,
                cursor: "pointer",
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                gap: 3,
                fontFamily: "inherit",
                fontSize: 10,
                fontWeight: 600,
              }}
            >
              <Icon size={20} />
              {t.label}
            </button>
          );
        })}
      </div>
    </div>
  );
};

// ── Helper: countdown a una fecha
window.useCountdown = (target) => {
  const [now, setNow] = React.useState(Date.now());
  React.useEffect(() => {
    const i = setInterval(() => setNow(Date.now()), 30000);
    return () => clearInterval(i);
  }, []);
  const t = new Date(target).getTime();
  const diff = Math.max(0, t - now);
  const dias = Math.floor(diff / 86400000);
  const horas = Math.floor((diff % 86400000) / 3600000);
  const mins = Math.floor((diff % 3600000) / 60000);
  if (dias >= 1) return `Faltan ${dias}d ${horas}h`;
  if (horas >= 1) return `Faltan ${horas}h ${mins}m`;
  return `Faltan ${mins}m`;
};

// ── Toast minimal
window.Toast = ({ msg, onDone }) => {
  React.useEffect(() => {
    if (!msg) return;
    const t = setTimeout(onDone, 2200);
    return () => clearTimeout(t);
  }, [msg]);
  if (!msg) return null;
  return (
    <div style={{
      position: "absolute",
      top: 78,
      left: "50%",
      transform: "translateX(-50%)",
      background: "rgba(52,212,144,0.18)",
      border: `1px solid ${C.greenBd}`,
      color: C.green,
      padding: "10px 16px",
      borderRadius: 12,
      fontSize: 13,
      fontWeight: 600,
      zIndex: 9999,
      display: "flex",
      alignItems: "center",
      gap: 8,
      maxWidth: 320,
      animation: "toastIn 0.3s ease",
    }}>
      <Icons.Check size={16} />
      {msg}
    </div>
  );
};

// ── Logo Dexon (texto)
window.LogoText = ({ size = 22 }) => (
  <div style={{
    display: "inline-flex",
    alignItems: "center",
    gap: 8,
  }}>
    <div style={{
      width: size + 6,
      height: size + 6,
      borderRadius: 8,
      background: `linear-gradient(135deg, ${C.coral}, ${C.coralD})`,
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      color: "#fff",
      fontWeight: 900,
      fontSize: size * 0.6,
      letterSpacing: -0.5,
    }}>D</div>
    <div style={{
      color: C.t1,
      fontWeight: 900,
      fontSize: size,
      letterSpacing: 2,
    }}>DEXON</div>
  </div>
);

// ── Avatar con iniciales
window.Avatar = ({ nombre, size = 40 }) => {
  const ini = (nombre || "").split(" ").map(s => s[0]).slice(0, 2).join("").toUpperCase();
  return (
    <div style={{
      width: size,
      height: size,
      borderRadius: "50%",
      background: `linear-gradient(135deg, ${C.coral}, ${C.coralD})`,
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      color: "#fff",
      fontWeight: 700,
      fontSize: size * 0.4,
      flexShrink: 0,
      boxShadow: "0 4px 14px rgba(224,91,40,0.3)",
    }}>{ini}</div>
  );
};
