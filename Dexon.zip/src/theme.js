// Dexon palette — espejo de src/lib/constants.js del repo
window.C = {
  bg: "#060D1A",
  bgCard: "#0C1628",
  bgElev: "#101D38",
  bgHover: "#162240",
  border: "#1A2E55",
  borderL: "#223870",
  coral: "#E05B28",
  coralL: "#FF7040",
  coralD: "#B84520",
  coralAlpha: "rgba(224,91,40,0.12)",
  blue: "#0A1628",
  blueM: "#1A3070",
  t1: "#EEF2FF",
  t2: "#8AA0CC",
  t3: "#4A6088",
  green: "#34D490",
  greenBg: "#071E12",
  greenBd: "#0F4025",
  yellow: "#F5C060",
  yellowBg: "#1A1208",
  yellowBd: "#3A2A10",
  red: "#F06060",
  redBg: "#1A0808",
  redBd: "#4A1010",
  purple: "#A080FF",
  purpleBg: "#120A30",
  purpleBd: "#2A1A60",
  info: "#5AA0F0",
  infoBg: "#081830",
};

window.fmtGs = (n) => "₲ " + new Intl.NumberFormat("es-PY").format(n);
window.fmtFecha = (d) => {
  const dias = ["Domingo", "Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado"];
  const meses = ["Ene", "Feb", "Mar", "Abr", "May", "Jun", "Jul", "Ago", "Sep", "Oct", "Nov", "Dic"];
  return dias[d.getDay()] + " " + d.getDate() + " " + meses[d.getMonth()];
};
window.fmtCorto = (d) => {
  const dias = ["Dom", "Lun", "Mar", "Mié", "Jue", "Vie", "Sáb"];
  return dias[d.getDay()] + " " + d.getDate();
};
