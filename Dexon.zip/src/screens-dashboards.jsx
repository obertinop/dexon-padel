// 3 variantes de Dashboard (home) — el resto de las pantallas son comunes.
const { useState: useStateHome } = React;

// ─────────────────────────────────────────────
// V1 — COMPACTO: header + hero + grid + lista
// ─────────────────────────────────────────────
window.DashboardV1 = ({ go, onLogout }) => {
  const { cliente, proximas } = MOCK;
  const next = proximas[0];
  const countdown = useCountdown(next.inicio);

  return (
    <div style={{ background: C.bg, color: C.t1, paddingBottom: 110 }}>
      {/* Header */}
      <div style={{ padding: "60px 20px 16px", display: "flex", alignItems: "center", gap: 12 }}>
        <Avatar nombre={cliente.nombre + " " + cliente.apellido} size={44} />
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 12, color: C.t3, fontWeight: 600 }}>Hola,</div>
          <div style={{ fontSize: 17, fontWeight: 700, color: C.t1, letterSpacing: -0.2 }}>{cliente.nombre} {cliente.apellido}</div>
        </div>
        <button onClick={() => go("notif")} style={iconBtn}>
          <Icons.Bell size={20} />
          <span style={{ position: "absolute", top: 8, right: 9, width: 7, height: 7, borderRadius: "50%", background: C.coral, border: `2px solid ${C.bg}` }} />
        </button>
      </div>

      {/* Hero — próximo turno */}
      <div style={{ padding: "0 20px 20px" }}>
        <div onClick={() => go("reservaDetalle", next)} style={{
          background: `linear-gradient(135deg, ${C.coralD} 0%, ${C.coral} 100%)`,
          borderRadius: 22,
          padding: "20px 22px",
          color: "#fff",
          cursor: "pointer",
          boxShadow: "0 14px 40px rgba(224,91,40,0.35)",
          position: "relative",
          overflow: "hidden",
        }}>
          <div style={{ position: "absolute", right: -30, top: -30, width: 160, height: 160, borderRadius: "50%", background: "rgba(255,255,255,0.08)" }} />
          <div style={{ position: "absolute", right: -60, bottom: -60, width: 180, height: 180, borderRadius: "50%", background: "rgba(255,255,255,0.05)" }} />

          <div style={{ position: "relative", display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 14 }}>
            <span style={{ fontSize: 10, fontWeight: 700, letterSpacing: 2, textTransform: "uppercase", opacity: 0.9 }}>Tu próximo turno</span>
            <span style={{ background: "rgba(255,255,255,0.18)", padding: "3px 9px", borderRadius: 100, fontSize: 10, fontWeight: 700 }}>{countdown}</span>
          </div>

          <div style={{ position: "relative", fontSize: 30, fontWeight: 800, letterSpacing: -1, lineHeight: 1, marginBottom: 4 }}>
            {String(next.inicio.getHours()).padStart(2, "0")}:{String(next.inicio.getMinutes()).padStart(2, "0")}
            <span style={{ fontSize: 16, fontWeight: 600, opacity: 0.8, marginLeft: 8 }}>· {next.duracion}min</span>
          </div>
          <div style={{ position: "relative", fontSize: 14, opacity: 0.95, marginBottom: 18 }}>
            {fmtFecha(next.inicio)} · {next.cancha}
          </div>

          <div style={{ position: "relative", display: "flex", gap: 8 }}>
            <button onClick={(e) => { e.stopPropagation(); go("reagendar", next); }} style={ctaWhite}>
              <Icons.RotateCcw size={14} /> Reagendar
            </button>
            <button onClick={(e) => { e.stopPropagation(); go("reservaDetalle", next); }} style={ctaOutline}>
              Ver detalle <Icons.ChevronRight size={14} />
            </button>
          </div>
        </div>
      </div>

      {/* Stats grid */}
      <div style={{ padding: "0 20px 20px", display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 10 }}>
        <StatTile icon={<Icons.Wallet />} value={fmtGs(cliente.saldo)} label="Saldo" onClick={() => go("referido")} valueFs={15} />
        <StatTile icon={<Icons.Trophy />} value={cliente.turnosJugados} label="Jugados" valueFs={18} />
        <StatTile icon={<Icons.Gift />} value={cliente.referidos} label="Referidos" onClick={() => go("referido")} valueFs={18} />
      </div>

      {/* Quick actions */}
      <div style={{ padding: "4px 20px 14px" }}>
        <div style={{ fontSize: 13, fontWeight: 700, color: C.t2, marginBottom: 12, letterSpacing: 0.5, textTransform: "uppercase" }}>Accesos rápidos</div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
          <QuickAction icon={<Icons.Plus />} label="Reservar turno" sub="Ver canchas libres" onClick={() => go("reservar")} accent />
          <QuickAction icon={<Icons.Crown />} label="Mi abono" sub={cliente.abonoDiaHora} onClick={() => go("abonos")} />
          <QuickAction icon={<Icons.Heart />} label="Favoritos" sub={`${MOCK.favoritos.length} horarios`} onClick={() => go("favoritos")} />
          <QuickAction icon={<Icons.Wallet />} label="Historial" sub="Pagos y facturas" onClick={() => go("pagos")} />
        </div>
      </div>

      {/* Próximas */}
      <div style={{ padding: "8px 20px 16px" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
          <div style={{ fontSize: 13, fontWeight: 700, color: C.t2, letterSpacing: 0.5, textTransform: "uppercase" }}>Próximos turnos</div>
          <button onClick={() => go("reservas")} style={{ background: "none", border: "none", color: C.coral, fontSize: 12, fontWeight: 700, cursor: "pointer", fontFamily: "inherit" }}>Ver todos →</button>
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          {proximas.slice(1).map(t => <ReservaRow key={t.id} t={t} onClick={() => go("reservaDetalle", t)} />)}
        </div>
      </div>
    </div>
  );
};

// ─────────────────────────────────────────────
// V2 — FEED: hero ticket + tarjetas apiladas
// ─────────────────────────────────────────────
window.DashboardV2 = ({ go, onLogout }) => {
  const { cliente, proximas } = MOCK;
  const next = proximas[0];
  const countdown = useCountdown(next.inicio);

  return (
    <div style={{ background: C.bg, color: C.t1, paddingBottom: 110 }}>
      <div style={{ padding: "58px 20px 8px", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <LogoText size={16} />
        <div style={{ display: "flex", gap: 8 }}>
          <button onClick={() => go("notif")} style={iconBtn}>
            <Icons.Bell size={18} />
            <span style={{ position: "absolute", top: 8, right: 9, width: 6, height: 6, borderRadius: "50%", background: C.coral }} />
          </button>
          <button onClick={() => go("perfil")} style={{ ...iconBtn, padding: 0 }}>
            <Avatar nombre={cliente.nombre + " " + cliente.apellido} size={36} />
          </button>
        </div>
      </div>

      <div style={{ padding: "12px 20px 18px" }}>
        <div style={{ fontSize: 22, fontWeight: 800, letterSpacing: -0.5, lineHeight: 1.2 }}>
          ¿Listo para jugar,<br/>
          <span style={{ color: C.coral }}>{cliente.nombre}?</span>
        </div>
      </div>

      {/* Ticket card */}
      <div style={{ padding: "0 20px 18px" }}>
        <div onClick={() => go("reservaDetalle", next)} style={{
          background: C.bgCard,
          borderRadius: 22,
          border: `1px solid ${C.border}`,
          padding: 0,
          overflow: "hidden",
          cursor: "pointer",
        }}>
          {/* Top strip */}
          <div style={{ background: `linear-gradient(135deg, ${C.coralD}, ${C.coral})`, padding: "12px 18px", color: "#fff", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <span style={{ fontSize: 11, fontWeight: 700, letterSpacing: 1.5, textTransform: "uppercase" }}>Tu próximo turno</span>
            <span style={{ fontSize: 11, fontWeight: 700, background: "rgba(0,0,0,0.18)", padding: "3px 9px", borderRadius: 100 }}>{countdown}</span>
          </div>

          <div style={{ padding: "20px 22px 18px" }}>
            <div style={{ display: "flex", alignItems: "flex-end", gap: 14, marginBottom: 18 }}>
              <div>
                <div style={{ fontSize: 48, fontWeight: 800, color: C.t1, lineHeight: 0.95, letterSpacing: -2 }}>
                  {String(next.inicio.getHours()).padStart(2, "0")}
                </div>
                <div style={{ fontSize: 16, color: C.t2, fontWeight: 700, marginTop: -2 }}>
                  :{String(next.inicio.getMinutes()).padStart(2, "0")}
                </div>
              </div>
              <div style={{ flex: 1, paddingBottom: 6 }}>
                <div style={{ fontSize: 16, fontWeight: 700, color: C.t1, marginBottom: 2, lineHeight: 1.2 }}>
                  {fmtFecha(next.inicio)}
                </div>
                <div style={{ fontSize: 13, color: C.t2, display: "flex", alignItems: "center", gap: 6 }}>
                  <Icons.MapPin size={13} /> {next.cancha} · {next.duracion}min
                </div>
              </div>
            </div>

            {/* perforated divider */}
            <div style={{ position: "relative", borderTop: `1px dashed ${C.border}`, margin: "0 -22px 16px" }}>
              <div style={{ position: "absolute", left: -10, top: -10, width: 20, height: 20, borderRadius: "50%", background: C.bg }} />
              <div style={{ position: "absolute", right: -10, top: -10, width: 20, height: 20, borderRadius: "50%", background: C.bg }} />
            </div>

            <div style={{ display: "flex", gap: 8 }}>
              <Btn variant="ghost" size="sm" onClick={(e) => { e.stopPropagation(); go("reagendar", next); }} icon={<Icons.RotateCcw />}>Reagendar</Btn>
              <Btn variant="ghost" size="sm" onClick={(e) => { e.stopPropagation(); go("reservaDetalle", next); }} style={{ flex: 1 }}>Ver detalle</Btn>
            </div>
          </div>
        </div>
      </div>

      {/* Saldo card */}
      <FeedCard
        onClick={() => go("referido")}
        icon={<Icons.Wallet size={22} />}
        accent
        title={fmtGs(cliente.saldo)}
        subtitle="Saldo a favor por referidos"
        action="Compartir código"
      />

      <FeedCard
        onClick={() => go("abonos")}
        icon={<Icons.Crown size={22} />}
        title="Abono activo"
        subtitle={`${cliente.abonoDiaHora} · hasta ${fmtCorto(cliente.abonoHasta)}`}
        action="Ver detalle"
      />

      <FeedCard
        onClick={() => go("reservar")}
        icon={<Icons.Sparkle size={22} />}
        coral
        title="¿Jugás este finde?"
        subtitle="3 horarios libres el sábado a la tarde"
        action="Reservar ahora"
      />

      <FeedCard
        onClick={() => go("favoritos")}
        icon={<Icons.Heart size={22} />}
        title="Tu horario habitual"
        subtitle="Martes 20:00 — repetir reserva en 1 toque"
        action="Reservar habitual"
      />

      <div style={{ padding: "20px 20px 8px", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <div style={{ fontSize: 13, fontWeight: 700, color: C.t2, letterSpacing: 0.5, textTransform: "uppercase" }}>Próximos</div>
        <button onClick={() => go("reservas")} style={{ background: "none", border: "none", color: C.coral, fontSize: 12, fontWeight: 700, cursor: "pointer", fontFamily: "inherit" }}>Ver todos →</button>
      </div>
      <div style={{ padding: "0 20px", display: "flex", flexDirection: "column", gap: 8 }}>
        {proximas.slice(1).map(t => <ReservaRow key={t.id} t={t} onClick={() => go("reservaDetalle", t)} />)}
      </div>
    </div>
  );
};

// ─────────────────────────────────────────────
// V3 — WALLET: saldo prominente + chips + tickets
// ─────────────────────────────────────────────
window.DashboardV3 = ({ go, onLogout }) => {
  const { cliente, proximas } = MOCK;
  const next = proximas[0];

  return (
    <div style={{ background: C.bg, color: C.t1, paddingBottom: 110, minHeight: "100%" }}>
      <div style={{ padding: "58px 20px 0", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <div>
          <div style={{ fontSize: 12, color: C.t3, fontWeight: 600, letterSpacing: 1, textTransform: "uppercase" }}>Mi cuenta</div>
          <div style={{ fontSize: 22, fontWeight: 800, color: C.t1, letterSpacing: -0.5 }}>{cliente.nombre} {cliente.apellido}</div>
        </div>
        <button onClick={() => go("notif")} style={iconBtn}>
          <Icons.Bell size={20} />
          <span style={{ position: "absolute", top: 8, right: 9, width: 7, height: 7, borderRadius: "50%", background: C.coral }} />
        </button>
      </div>

      {/* Wallet card */}
      <div style={{ padding: "20px 20px 8px" }}>
        <div style={{
          background: `linear-gradient(160deg, #1A3070 0%, #0A1628 60%, #060D1A 100%)`,
          borderRadius: 26,
          border: `1px solid ${C.borderL}`,
          padding: "22px 22px 18px",
          position: "relative",
          overflow: "hidden",
          boxShadow: "0 16px 40px rgba(0,0,0,0.4)",
        }}>
          <div style={{ position: "absolute", right: -60, top: -60, width: 220, height: 220, borderRadius: "50%", background: `radial-gradient(circle, rgba(224,91,40,0.25), transparent 60%)` }} />
          <div style={{ position: "relative", display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 18 }}>
            <div>
              <div style={{ fontSize: 11, color: C.t2, fontWeight: 600, letterSpacing: 1.5, textTransform: "uppercase" }}>Saldo a favor</div>
              <div style={{ fontSize: 36, fontWeight: 800, color: C.t1, letterSpacing: -1, marginTop: 4 }}>{fmtGs(cliente.saldo)}</div>
              <div style={{ fontSize: 12, color: C.t3, marginTop: 4 }}>{cliente.referidos} amigos invitados · acumulado</div>
            </div>
            <div style={{ width: 48, height: 48, borderRadius: 14, background: `linear-gradient(135deg, ${C.coral}, ${C.coralD})`, display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", boxShadow: "0 8px 20px rgba(224,91,40,0.4)" }}>
              <Icons.Gift size={22} />
            </div>
          </div>
          <div style={{ position: "relative", display: "flex", gap: 8 }}>
            <button onClick={() => go("referido")} style={ctaWhite}>
              <Icons.Share size={14} /> Compartir código
            </button>
            <button onClick={() => go("pagos")} style={ctaOutline}>
              Movimientos
            </button>
          </div>
        </div>
      </div>

      {/* Chips fila */}
      <div style={{ padding: "12px 0 8px", overflowX: "auto" }}>
        <div style={{ display: "flex", gap: 10, padding: "4px 20px" }}>
          <Chip icon={<Icons.Plus />} label="Reservar" coral onClick={() => go("reservar")} />
          <Chip icon={<Icons.Crown />} label="Mi abono" onClick={() => go("abonos")} />
          <Chip icon={<Icons.Heart />} label="Favoritos" onClick={() => go("favoritos")} />
          <Chip icon={<Icons.Wallet />} label="Pagos" onClick={() => go("pagos")} />
          <Chip icon={<Icons.Settings />} label="Ajustes" onClick={() => go("notif")} />
        </div>
      </div>

      {/* Próximo turno destacado, minimal */}
      <div style={{ padding: "12px 20px 8px" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
          <div style={{ fontSize: 13, fontWeight: 700, color: C.t2, letterSpacing: 0.5, textTransform: "uppercase" }}>Próximo turno</div>
          <span style={{ fontSize: 11, color: C.coral, fontWeight: 700 }}>{useCountdown(next.inicio)}</span>
        </div>

        <div onClick={() => go("reservaDetalle", next)} style={{
          background: C.bgCard,
          border: `1px solid ${C.coral}33`,
          borderRadius: 20,
          padding: 0,
          overflow: "hidden",
          cursor: "pointer",
          display: "flex",
        }}>
          <div style={{ background: `linear-gradient(180deg, ${C.coral}, ${C.coralD})`, width: 6 }} />
          <div style={{ flex: 1, padding: "16px 18px", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <div>
              <div style={{ fontSize: 11, color: C.t3, fontWeight: 600, marginBottom: 4 }}>{fmtFecha(next.inicio).toUpperCase()}</div>
              <div style={{ fontSize: 22, fontWeight: 800, color: C.t1, letterSpacing: -0.5, lineHeight: 1 }}>
                {String(next.inicio.getHours()).padStart(2, "0")}:{String(next.inicio.getMinutes()).padStart(2, "0")}
              </div>
              <div style={{ fontSize: 12, color: C.t2, marginTop: 4 }}>{next.cancha} · {next.duracion}min</div>
            </div>
            <Icons.ChevronRight size={20} color={C.t3} />
          </div>
        </div>
      </div>

      <div style={{ padding: "16px 20px 8px", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <div style={{ fontSize: 13, fontWeight: 700, color: C.t2, letterSpacing: 0.5, textTransform: "uppercase" }}>Más turnos</div>
        <button onClick={() => go("reservas")} style={{ background: "none", border: "none", color: C.coral, fontSize: 12, fontWeight: 700, cursor: "pointer", fontFamily: "inherit" }}>Ver todos →</button>
      </div>
      <div style={{ padding: "0 20px", display: "flex", flexDirection: "column", gap: 8 }}>
        {proximas.slice(1).map(t => <ReservaRow key={t.id} t={t} onClick={() => go("reservaDetalle", t)} />)}
      </div>

      <div style={{ padding: "20px", display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
        <Card padding={16}>
          <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 8, color: C.coral }}>
            <Icons.Trophy size={18} /> <span style={{ fontSize: 11, fontWeight: 700, letterSpacing: 1, textTransform: "uppercase", color: C.t2 }}>Jugados</span>
          </div>
          <div style={{ fontSize: 26, fontWeight: 800, color: C.t1, letterSpacing: -0.5 }}>{cliente.turnosJugados}</div>
          <div style={{ fontSize: 11, color: C.t3, marginTop: 2 }}>turnos este año</div>
        </Card>
        <Card padding={16}>
          <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 8, color: C.coral }}>
            <Icons.Sparkle size={18} /> <span style={{ fontSize: 11, fontWeight: 700, letterSpacing: 1, textTransform: "uppercase", color: C.t2 }}>Racha</span>
          </div>
          <div style={{ fontSize: 26, fontWeight: 800, color: C.t1, letterSpacing: -0.5 }}>{cliente.racha} sem</div>
          <div style={{ fontSize: 11, color: C.t3, marginTop: 2 }}>seguidas jugando</div>
        </Card>
      </div>
    </div>
  );
};

// ── helpers locales
const iconBtn = {
  position: "relative",
  background: C.bgCard,
  border: `1px solid ${C.border}`,
  width: 40,
  height: 40,
  borderRadius: 14,
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  color: C.t1,
  cursor: "pointer",
};

const ctaWhite = {
  flex: 1,
  background: "rgba(255,255,255,0.95)",
  border: "none",
  color: "#0A1525",
  padding: "10px 14px",
  borderRadius: 12,
  fontWeight: 700,
  fontSize: 13,
  cursor: "pointer",
  fontFamily: "inherit",
  display: "inline-flex",
  alignItems: "center",
  justifyContent: "center",
  gap: 6,
};

const ctaOutline = {
  flex: 1,
  background: "rgba(255,255,255,0.12)",
  border: "1px solid rgba(255,255,255,0.18)",
  color: "#fff",
  padding: "10px 14px",
  borderRadius: 12,
  fontWeight: 600,
  fontSize: 13,
  cursor: "pointer",
  fontFamily: "inherit",
  display: "inline-flex",
  alignItems: "center",
  justifyContent: "center",
  gap: 6,
};

const StatTile = ({ icon, value, label, onClick, valueFs = 20 }) => (
  <div onClick={onClick} style={{
    background: C.bgCard,
    border: `1px solid ${C.border}`,
    borderRadius: 16,
    padding: "14px 12px",
    cursor: onClick ? "pointer" : "default",
    display: "flex",
    flexDirection: "column",
    gap: 6,
  }}>
    <div style={{ color: C.coral, opacity: 0.9 }}>{React.cloneElement(icon, { size: 18 })}</div>
    <div style={{ fontSize: valueFs, fontWeight: 800, color: C.t1, letterSpacing: -0.5, lineHeight: 1 }}>{value}</div>
    <div style={{ fontSize: 11, color: C.t3, fontWeight: 600 }}>{label}</div>
  </div>
);

const QuickAction = ({ icon, label, sub, onClick, accent }) => (
  <button onClick={onClick} style={{
    background: accent ? C.coralAlpha : C.bgCard,
    border: `1px solid ${accent ? C.coral + "55" : C.border}`,
    borderRadius: 16,
    padding: "14px 14px",
    textAlign: "left",
    cursor: "pointer",
    fontFamily: "inherit",
    color: C.t1,
    display: "flex",
    flexDirection: "column",
    gap: 8,
  }}>
    <div style={{
      width: 36,
      height: 36,
      borderRadius: 11,
      background: accent ? `linear-gradient(135deg, ${C.coral}, ${C.coralD})` : C.bgElev,
      color: accent ? "#fff" : C.coral,
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
    }}>{React.cloneElement(icon, { size: 18 })}</div>
    <div>
      <div style={{ fontSize: 14, fontWeight: 700, color: C.t1, marginBottom: 1 }}>{label}</div>
      <div style={{ fontSize: 11, color: C.t3 }}>{sub}</div>
    </div>
  </button>
);

const FeedCard = ({ icon, title, subtitle, action, onClick, accent, coral: isCoral }) => (
  <div onClick={onClick} style={{
    margin: "0 20px 10px",
    background: isCoral ? C.coralAlpha : C.bgCard,
    border: `1px solid ${isCoral ? C.coral + "55" : C.border}`,
    borderRadius: 18,
    padding: "16px 18px",
    cursor: "pointer",
    display: "flex",
    alignItems: "center",
    gap: 14,
  }}>
    <div style={{
      width: 44,
      height: 44,
      borderRadius: 14,
      background: accent ? `linear-gradient(135deg, ${C.coral}, ${C.coralD})` : (isCoral ? "rgba(224,91,40,0.25)" : C.bgElev),
      color: accent ? "#fff" : C.coral,
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      flexShrink: 0,
    }}>{icon}</div>
    <div style={{ flex: 1, minWidth: 0 }}>
      <div style={{ fontSize: 15, fontWeight: 700, color: C.t1, letterSpacing: -0.2, marginBottom: 2 }}>{title}</div>
      <div style={{ fontSize: 12, color: C.t2, lineHeight: 1.4 }}>{subtitle}</div>
    </div>
    <div style={{ display: "flex", alignItems: "center", gap: 4, color: isCoral ? C.coral : C.t2, fontSize: 12, fontWeight: 600 }}>
      <Icons.ChevronRight size={18} />
    </div>
  </div>
);

const Chip = ({ icon, label, onClick, coral: isCoral }) => (
  <button onClick={onClick} style={{
    background: isCoral ? `linear-gradient(135deg, ${C.coral}, ${C.coralD})` : C.bgCard,
    border: `1px solid ${isCoral ? "transparent" : C.border}`,
    borderRadius: 14,
    padding: "10px 14px",
    color: isCoral ? "#fff" : C.t1,
    fontWeight: 600,
    fontSize: 13,
    cursor: "pointer",
    display: "inline-flex",
    alignItems: "center",
    gap: 6,
    fontFamily: "inherit",
    whiteSpace: "nowrap",
    boxShadow: isCoral ? "0 8px 20px rgba(224,91,40,0.35)" : "none",
    flexShrink: 0,
  }}>
    {React.cloneElement(icon, { size: 16 })}
    {label}
  </button>
);

window.ReservaRow = ({ t, onClick }) => {
  const isAbono = t.tipo === "abono";
  const isPending = !t.pagado && t.pago !== "abono";
  return (
    <div onClick={onClick} style={{
      background: C.bgCard,
      border: `1px solid ${C.border}`,
      borderRadius: 16,
      padding: "12px 14px",
      display: "flex",
      gap: 14,
      alignItems: "center",
      cursor: "pointer",
    }}>
      <div style={{
        width: 52,
        height: 52,
        borderRadius: 14,
        background: isAbono ? C.purpleBg : (isPending ? C.yellowBg : C.bgElev),
        border: `1px solid ${isAbono ? C.purpleBd : (isPending ? C.yellowBd : C.border)}`,
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        flexShrink: 0,
      }}>
        <div style={{ fontSize: 9, color: C.t3, fontWeight: 700, letterSpacing: 0.5 }}>{["DOM","LUN","MAR","MIÉ","JUE","VIE","SÁB"][t.inicio.getDay()]}</div>
        <div style={{ fontSize: 18, fontWeight: 800, color: C.t1, lineHeight: 1 }}>{t.inicio.getDate()}</div>
      </div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: 14, fontWeight: 700, color: C.t1, marginBottom: 2 }}>
          {String(t.inicio.getHours()).padStart(2, "0")}:{String(t.inicio.getMinutes()).padStart(2, "0")} · {t.duracion}min
        </div>
        <div style={{ fontSize: 12, color: C.t2 }}>{t.cancha}</div>
      </div>
      <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", gap: 4 }}>
        {isAbono && <Badge tone="purple">Abono</Badge>}
        {isPending && <Badge tone="yellow">Por pagar</Badge>}
        {!isAbono && !isPending && <Badge tone="green">Confirmado</Badge>}
        <Icons.ChevronRight size={16} color={C.t3} />
      </div>
    </div>
  );
};
