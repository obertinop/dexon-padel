// Iconos SVG line — estilo Lucide. Sin emoji para el feel "modern app".
const Ico = ({ d, size = 22, stroke = "currentColor", fill = "none", sw = 1.8, children }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill={fill} stroke={stroke} strokeWidth={sw} strokeLinecap="round" strokeLinejoin="round">
    {d ? <path d={d} /> : children}
  </svg>
);

window.Icons = {
  Home: (p) => <Ico {...p}><path d="M3 11l9-7 9 7v9a2 2 0 0 1-2 2h-4v-7H9v7H5a2 2 0 0 1-2-2v-9z" /></Ico>,
  Calendar: (p) => <Ico {...p}><rect x="3" y="5" width="18" height="16" rx="2" /><path d="M16 3v4M8 3v4M3 10h18" /></Ico>,
  Plus: (p) => <Ico {...p}><path d="M12 5v14M5 12h14" /></Ico>,
  User: (p) => <Ico {...p}><circle cx="12" cy="8" r="4" /><path d="M4 21a8 8 0 0 1 16 0" /></Ico>,
  Wallet: (p) => <Ico {...p}><rect x="3" y="6" width="18" height="14" rx="2" /><path d="M3 10h18M16 15h2" /></Ico>,
  Gift: (p) => <Ico {...p}><rect x="3" y="9" width="18" height="12" rx="1" /><path d="M3 13h18M12 9v12M8 9a2 2 0 1 1 0-4c1.5 0 4 4 4 4s-2.5 0-4 0zM16 9a2 2 0 1 0 0-4c-1.5 0-4 4-4 4s2.5 0 4 0z" /></Ico>,
  Bell: (p) => <Ico {...p}><path d="M18 16v-5a6 6 0 1 0-12 0v5l-2 2h16l-2-2zM10 20a2 2 0 0 0 4 0" /></Ico>,
  Heart: (p) => <Ico {...p}><path d="M12 20s-7-4.5-7-10a4 4 0 0 1 7-2.5A4 4 0 0 1 19 10c0 5.5-7 10-7 10z" /></Ico>,
  Clock: (p) => <Ico {...p}><circle cx="12" cy="12" r="9" /><path d="M12 7v5l3 2" /></Ico>,
  ArrowRight: (p) => <Ico {...p}><path d="M5 12h14M13 5l7 7-7 7" /></Ico>,
  ArrowLeft: (p) => <Ico {...p}><path d="M19 12H5M11 5l-7 7 7 7" /></Ico>,
  Check: (p) => <Ico {...p}><path d="M5 12l5 5L20 7" /></Ico>,
  X: (p) => <Ico {...p}><path d="M6 6l12 12M6 18L18 6" /></Ico>,
  Share: (p) => <Ico {...p}><path d="M12 4v12M8 8l4-4 4 4M4 20h16" /></Ico>,
  Copy: (p) => <Ico {...p}><rect x="9" y="9" width="11" height="11" rx="2" /><path d="M5 15H4a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v1" /></Ico>,
  Whatsapp: (p) => <Ico fill="currentColor" stroke="none" {...p}><path d="M12.05 2C6.5 2 2 6.5 2 12.05c0 1.78.47 3.52 1.36 5.05L2 22l5.05-1.32a10 10 0 0 0 5 1.32C17.55 22 22 17.55 22 12.05 22 6.5 17.55 2 12.05 2zm5.45 14.18c-.23.65-1.34 1.24-1.87 1.32-.48.07-1.09.1-1.75-.11-.4-.13-.92-.3-1.58-.59-2.78-1.2-4.6-4-4.74-4.18-.14-.18-1.13-1.5-1.13-2.86 0-1.36.71-2.03.97-2.31.25-.28.55-.35.74-.35.18 0 .37.01.53.01.17.01.4-.06.62.47.23.55.78 1.91.85 2.05.07.14.12.3.02.48-.09.18-.14.3-.28.46-.14.16-.29.36-.41.49-.14.14-.28.29-.12.57.16.28.71 1.17 1.52 1.89 1.04.93 1.92 1.21 2.2 1.35.27.14.43.12.59-.07.16-.18.68-.79.86-1.06.18-.28.36-.23.61-.14.25.09 1.6.75 1.87.89.27.14.46.2.53.32.07.12.07.69-.16 1.34z" /></Ico>,
  Star: (p) => <Ico {...p}><path d="M12 3l2.5 6 6.5.5-5 4.5 1.5 6.5-5.5-3.5-5.5 3.5 1.5-6.5-5-4.5 6.5-.5L12 3z" /></Ico>,
  Edit: (p) => <Ico {...p}><path d="M4 20h4l11-11-4-4L4 16v4z" /></Ico>,
  Phone: (p) => <Ico {...p}><path d="M5 4h4l2 5-3 2a12 12 0 0 0 5 5l2-3 5 2v4a2 2 0 0 1-2 2A17 17 0 0 1 3 6a2 2 0 0 1 2-2z" /></Ico>,
  Mail: (p) => <Ico {...p}><rect x="3" y="5" width="18" height="14" rx="2" /><path d="M3 7l9 6 9-6" /></Ico>,
  Logout: (p) => <Ico {...p}><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9" /></Ico>,
  ChevronRight: (p) => <Ico {...p}><path d="M9 6l6 6-6 6" /></Ico>,
  ChevronDown: (p) => <Ico {...p}><path d="M6 9l6 6 6-6" /></Ico>,
  MapPin: (p) => <Ico {...p}><path d="M12 22s-7-7-7-12a7 7 0 1 1 14 0c0 5-7 12-7 12z" /><circle cx="12" cy="10" r="2.5" /></Ico>,
  Crown: (p) => <Ico {...p}><path d="M3 8l4 4 5-7 5 7 4-4-2 11H5L3 8z" /></Ico>,
  Trophy: (p) => <Ico {...p}><path d="M7 4h10v5a5 5 0 0 1-10 0V4zM5 4h2v3a2 2 0 0 1-2-2V4zm14 0h-2v3a2 2 0 0 0 2-2V4zM9 17h6v3H9z" /></Ico>,
  Sparkle: (p) => <Ico {...p}><path d="M12 3l1.5 5L19 9.5 13.5 11 12 16l-1.5-5L5 9.5 10.5 8 12 3z" /></Ico>,
  Settings: (p) => <Ico {...p}><circle cx="12" cy="12" r="3" /><path d="M19 12a7 7 0 0 0-.1-1.2l2-1.5-2-3.4-2.4.9a7 7 0 0 0-2-1.2L14 3h-4l-.5 2.6a7 7 0 0 0-2 1.2l-2.4-.9-2 3.4 2 1.5A7 7 0 0 0 5 12a7 7 0 0 0 .1 1.2l-2 1.5 2 3.4 2.4-.9a7 7 0 0 0 2 1.2L10 21h4l.5-2.6a7 7 0 0 0 2-1.2l2.4.9 2-3.4-2-1.5A7 7 0 0 0 19 12z" /></Ico>,
  RotateCcw: (p) => <Ico {...p}><path d="M3 12a9 9 0 1 0 3-6.7L3 8M3 3v5h5" /></Ico>,
  Trash: (p) => <Ico {...p}><path d="M4 7h16M9 7V4h6v3m-7 0v13a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1V7" /></Ico>,
};
