# Dexon Padel — Sección "Mi Cuenta"

Portal del cliente con login por WhatsApp OTP, dashboard de turnos, reagendamiento, referidos y perfil.

Prototipo navegable: abrí `Mi Cuenta.html` para clickear el flujo completo en un iPhone. Usá el panel **Tweaks** para alternar entre las 3 variantes de dashboard o saltar a cualquier pantalla.

---

## 📋 Resumen rápido para implementar

1. **DB** → Correr `01-migration.sql` en Supabase SQL Editor.
2. **WhatsApp** → Crear template `dexon_codigo` en Meta Business Manager (ver más abajo).
3. **Backend** → Copiar `api/cliente/*` al directorio `api/cliente/` del repo.
4. **Frontend** → Copiar `src/lib/cliente-api.js` y `src/components/MiCuenta.js` a las rutas correspondientes.
5. **Routing** → Agregar la ruta `/cuenta` en `App.js` (snippet abajo).
6. **Deploy** → `git push` y Vercel se encarga.

---

## 🗄️ 1. Migración Supabase

Pegá `implementation/01-migration.sql` en **Supabase → SQL Editor → Run**.

Tablas nuevas:
- `otp_codes` — códigos de verificación temporales (6 dígitos, 5 min de vigencia)
- `cliente_sessions` — tokens de sesión del cliente (30 días)
- `cliente_favoritos` — horarios habituales del cliente

Columnas agregadas a `clientes`:
- `email` (text, opcional)
- `notif_recordatorio`, `notif_promo`, `notif_email_resumen`, `notif_sms_urgente` (booleans)
- `ultimo_acceso` (timestamptz)

Función nueva: `limpiar_otps_vencidos()` — correrla en cron diario opcional.

---

## 📱 2. WhatsApp Template `dexon_codigo`

En **Meta Business Manager → WhatsApp Manager → Plantillas de mensaje**, crear:

- **Nombre**: `dexon_codigo`
- **Idioma**: Español (`es`)
- **Categoría**: Autenticación
- **Cuerpo** (con 1 variable):

```
Tu código de acceso a Dexon Padel es: {{1}}

Por seguridad, no compartas este código con nadie. Vence en 5 minutos.
```

**Importante**: si Meta no aprueba como "Autenticación", probá "Utilidad" con el mismo cuerpo.

El backend lo invoca así (ya está en `api/cliente/auth-send.js`):

```js
template: {
  name: "dexon_codigo",
  language: { code: "es" },
  components: [{ type: "body", parameters: [{ type: "text", text: codigo }] }],
}
```

---

## ⚙️ 3. Endpoints backend (Vercel)

Copiar los 4 archivos de `implementation/api/cliente/` al directorio `api/cliente/` del repo:

| Endpoint                        | Método | Función                                                      |
|---------------------------------|--------|--------------------------------------------------------------|
| `/api/cliente/auth-send`        | POST   | Manda OTP por WhatsApp (template `dexon_codigo`)              |
| `/api/cliente/auth-verify`      | POST   | Verifica OTP, crea cliente si no existe, devuelve token       |
| `/api/cliente/me`               | GET    | Datos del cliente (perfil + turnos + pagos + abono + ref)     |
| `/api/cliente/turno-accion`     | POST   | Reagendar / cancelar / pagar un turno propio                  |

**Variables de entorno** ya configuradas en el repo (no hacen falta nuevas):
- `SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY`
- `WHATSAPP_PHONE_NUMBER_ID`, `WHATSAPP_TOKEN`
- `APP_URL` (para CORS)

**Endpoints adicionales pendientes** (stub-eados desde el frontend, completalos cuando los necesites):
- `GET  /api/cliente/disponibilidad?desde=...&hasta=...` — slots libres (podés reusar la lógica de `api/reservar.js`)
- `PATCH /api/cliente/perfil` — editar nombre/email
- `PATCH /api/cliente/notif` — preferencias de notificación
- `POST/DELETE /api/cliente/favoritos` — CRUD favoritos

Todos requieren el mismo middleware de auth — usá `autenticarCliente(req)` exportado desde `me.js`.

---

## 🎨 4. Frontend

Copiar:
- `implementation/src/lib/cliente-api.js` → `src/lib/cliente-api.js`
- `implementation/src/components/MiCuenta.js` → `src/components/MiCuenta.js`

El componente está autocontenido y usa:
- `C` palette y constantes de `src/lib/constants.js` (ya existe)
- `Btn`, `Badge`, `Modal`, `Avatar` de `src/components/UI.js` (ya existe)
- `clienteAuth`, `clienteData`, `clienteSession` del nuevo `cliente-api.js`

No tiene dependencias nuevas en `package.json`. Solo React (que ya está).

---

## 🛣️ 5. Routing en App.js

Agregá la ruta. Buscá en `src/App.js` el handler de rutas (algo como `if (path === "/reservar") …`) y agregá:

```js
import MiCuenta from "./components/MiCuenta.js";

// dentro del componente App, donde decidís qué pantalla mostrar:
if (path === "/cuenta" || path === "/mi-cuenta") {
  return <MiCuenta />;
}
```

Y agregá un link "Mi cuenta" en `LandingPage.js` (junto al "Reservar →"):

```jsx
<a href="/cuenta" style={st.navLink}>Mi cuenta</a>
```

---

## 🧪 6. Probar localmente

```bash
npm run dev
# abrí http://localhost:5173/cuenta
```

El frontend va a fallar las API calls hasta que tengas los endpoints deployados o uses `vercel dev`. Para probar puramente el UI sin backend, mockeá el bloque inicial de `MiCuenta.js`:

```js
const [session, setSession] = useState({ token: "demo", cliente: { id: 1, nombre: "Pablo", apellido: "O.", telefono: "+595994821477", referrer_code: "REF-DEMO1234", saldo_favor: 60000, notif: {} } });
const [data, setData] = useState({ cliente: session.cliente, proximas: [], pasadas: [], pagos: [], favoritos: [], abono: null, referidos: { total: 0, lista: [] } });
```

---

## 🔐 Seguridad

- Los tokens de sesión cliente son **256 bits aleatorios** guardados en `cliente_sessions`. Sin JWT — validación contra DB para poder revocar al instante.
- RLS: todas las tablas nuevas son `service_role only`. El cliente nunca habla directo a Supabase, todo va por nuestros endpoints.
- OTP: 5 intentos máx, 5 min de vigencia, rate-limit de 60s entre reenvíos por mismo número.
- CORS: limitado a `APP_URL`.
- Recomendación: agregá Cloudflare Turnstile o hCaptcha en `/auth-send` antes de salir a producción para evitar abuso de WhatsApp.

---

## ⏰ Política de reagendamiento

Configurada en `api/cliente/turno-accion.js`:

```js
const HORAS_LIMITE = 12;
```

Cambiar este número modifica la política para reagendar **y** cancelar. Los turnos de tipo `abono` no se pueden auto-reagendar/cancelar (van por el admin).

---

## 🎯 Variantes del dashboard

El prototipo muestra **3 layouts** del home. La implementación en `MiCuenta.js` viene con **V2 (Feed)** porque es la más conversacional y mobile-first. Para cambiar:

- **V1 (Compacto)** — header + hero card + grid 3 stats + accesos rápidos 2×2. Más denso, ideal si tu base de usuarios es power-user.
- **V2 (Feed)** — implementado por default. Stack vertical de cards, hero tipo ticket de avión. Muy app-style.
- **V3 (Wallet)** — saldo prominente arriba, chips horizontales, ticket minimal. Premium, foco en el dinero.

Los 3 están en el prototipo (`src/screens-dashboards.jsx`) — copialos a `MiCuenta.js` si querés ofrecer A/B testing.

---

## 📦 Estructura final

```
dexon-padel/
├── api/
│   └── cliente/
│       ├── auth-send.js          ← nuevo
│       ├── auth-verify.js        ← nuevo
│       ├── me.js                 ← nuevo
│       ├── turno-accion.js       ← nuevo
│       └── (perfil, notif, favoritos, disponibilidad)  ← pendientes (stub)
├── src/
│   ├── components/
│   │   ├── MiCuenta.js           ← nuevo
│   │   ├── PortalCliente.js      (existente)
│   │   └── ...
│   └── lib/
│       ├── cliente-api.js        ← nuevo
│       ├── api.js                (existente)
│       └── ...
└── implementation/
    ├── 00-README.md              (este archivo)
    └── 01-migration.sql          ← correr en Supabase
```

---

## 🚀 Checklist de release

- [ ] Migración corrida en Supabase prod
- [ ] Template `dexon_codigo` aprobado por Meta
- [ ] Variables de entorno en Vercel verificadas
- [ ] Endpoints `auth-send` y `auth-verify` deployados
- [ ] Endpoint `me` deployado
- [ ] Endpoint `turno-accion` deployado
- [ ] Endpoints pendientes implementados (perfil/notif/favoritos/disponibilidad)
- [ ] Ruta `/cuenta` agregada en `App.js`
- [ ] Link "Mi cuenta" en `LandingPage.js`
- [ ] Smoke test: login con número real, ver dashboard, intentar reagendar
- [ ] Cron job para `limpiar_otps_vencidos()` (Vercel Cron, semanal está bien)
