-- ============================================================
-- DEXON PADEL — Migración para sección "Mi cuenta"
-- Pegá esto en Supabase → SQL Editor → Run
-- (después de la migración base ya existente)
-- ============================================================

-- ── 1. OTP CODES — códigos de verificación por WhatsApp ─────
CREATE TABLE IF NOT EXISTS otp_codes (
  id          bigserial PRIMARY KEY,
  telefono    text NOT NULL,
  codigo      text NOT NULL,           -- 6 dígitos
  intentos    int  DEFAULT 0,
  usado       boolean DEFAULT false,
  expira_en   timestamptz NOT NULL,
  creado_en   timestamptz DEFAULT now(),
  ip          text
);
CREATE INDEX IF NOT EXISTS otp_codes_tel_idx     ON otp_codes(telefono);
CREATE INDEX IF NOT EXISTS otp_codes_expira_idx  ON otp_codes(expira_en);

-- ── 2. CLIENTE SESSIONS — tokens de sesión cliente ──────────
CREATE TABLE IF NOT EXISTS cliente_sessions (
  id          bigserial PRIMARY KEY,
  cliente_id  bigint NOT NULL REFERENCES clientes(id) ON DELETE CASCADE,
  token       text   NOT NULL UNIQUE,
  expira_en   timestamptz NOT NULL,    -- típicamente 30 días
  creado_en   timestamptz DEFAULT now(),
  ip          text,
  user_agent  text,
  last_seen   timestamptz DEFAULT now()
);
CREATE INDEX IF NOT EXISTS cliente_sessions_token_idx  ON cliente_sessions(token);
CREATE INDEX IF NOT EXISTS cliente_sessions_cliente_idx ON cliente_sessions(cliente_id);

-- ── 3. Columnas extra en clientes ──────────────────────────
ALTER TABLE clientes ADD COLUMN IF NOT EXISTS email            text;
ALTER TABLE clientes ADD COLUMN IF NOT EXISTS notif_recordatorio  boolean DEFAULT true;
ALTER TABLE clientes ADD COLUMN IF NOT EXISTS notif_promo         boolean DEFAULT false;
ALTER TABLE clientes ADD COLUMN IF NOT EXISTS notif_email_resumen boolean DEFAULT false;
ALTER TABLE clientes ADD COLUMN IF NOT EXISTS notif_sms_urgente   boolean DEFAULT true;
ALTER TABLE clientes ADD COLUMN IF NOT EXISTS ultimo_acceso       timestamptz;

-- ── 4. FAVORITOS — horarios habituales del cliente ──────────
CREATE TABLE IF NOT EXISTS cliente_favoritos (
  id          bigserial PRIMARY KEY,
  cliente_id  bigint NOT NULL REFERENCES clientes(id) ON DELETE CASCADE,
  dia_semana  int    NOT NULL,         -- 0=domingo, 6=sábado
  hora        text   NOT NULL,         -- "20:00"
  duracion    int    DEFAULT 60,       -- minutos
  label       text,
  creado_en   timestamptz DEFAULT now()
);
CREATE INDEX IF NOT EXISTS cliente_favoritos_cliente_idx ON cliente_favoritos(cliente_id);

-- ── 5. RLS — todas service_role ──────────────────────────────
ALTER TABLE otp_codes          ENABLE ROW LEVEL SECURITY;
ALTER TABLE cliente_sessions   ENABLE ROW LEVEL SECURITY;
ALTER TABLE cliente_favoritos  ENABLE ROW LEVEL SECURITY;

CREATE POLICY "otp_service" ON otp_codes
  FOR ALL TO service_role USING (true) WITH CHECK (true);
CREATE POLICY "sessions_service" ON cliente_sessions
  FOR ALL TO service_role USING (true) WITH CHECK (true);
CREATE POLICY "favoritos_service" ON cliente_favoritos
  FOR ALL TO service_role USING (true) WITH CHECK (true);

-- ── 6. FUNCIÓN — limpiar OTPs vencidos (correr en cron diario) ─
CREATE OR REPLACE FUNCTION limpiar_otps_vencidos()
RETURNS int
LANGUAGE plpgsql
AS $$
DECLARE
  n int;
BEGIN
  DELETE FROM otp_codes
    WHERE expira_en < now() - interval '1 day'
    RETURNING 1 INTO n;
  RETURN COALESCE(n, 0);
END;
$$;

-- ============================================================
-- FIN. Verificar con:
-- SELECT * FROM otp_codes LIMIT 1;
-- SELECT * FROM cliente_sessions LIMIT 1;
-- ============================================================
